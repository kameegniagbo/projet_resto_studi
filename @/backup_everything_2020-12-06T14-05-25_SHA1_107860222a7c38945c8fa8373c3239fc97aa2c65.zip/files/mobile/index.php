<?php    
header('Location: https://www.rfi.fr');      
?>
