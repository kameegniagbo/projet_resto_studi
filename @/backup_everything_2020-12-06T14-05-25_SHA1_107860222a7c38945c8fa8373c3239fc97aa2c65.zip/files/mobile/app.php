<?php
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$todayDate = date('d-m-Y');
$thisMonthYear = date('m-Y');

//##########################################################################

if($_GET)
{
$op=$_GET["op"];
}

//########################################################################### check user exist

function checkUserAuth() {
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    $table_name = "appUsers";
    $select="*";
    $where="WHERE username='".$_GET["clt_username"]."' AND  password='".$_GET["clt_password"]."' AND  phoneID='".$_GET["clt_phoneID"]."'  ";
    $result = DBSelect($table_name, $select, $where);
    $row = mysqli_fetch_assoc($result);
    
    if (mysqli_num_rows($result) < 1)
    {
    //echo '0';
    ?>
    <script>
        openToast({
          message: 'Compte erroné, inexistant ou déjà utilisé',
          class: 'red-800 radius-big',
          position: 'top'
        });
        $('#connectedUser').html('<div  class="align-center red-800 text-white">Erreur d\'authentification... </div>' );
    </script>
    <?php
    exit;
    }
    else
    {
    //echo '1';
    ?>
    <script>
        $('#connectedUser').html('<div  class="align-center blue-800 text-white">N° connecté: ' + '<?php echo $row["username"]; ?></div>');
        closeLoading(); // This will hide ajax spinner 
        setTimeout(function(){ 
                openToast({
                message: 'Connexion validée',
                class: 'blue-800 radius-big',
                position: 'bottom'
                });
          }, 1000);
        setTimeout(function(){ 
              openToast({
              message: 'BRAVO! Vous obtenez <br>le mois de Décembre gratuit.',
              class: 'green-800 radius-big',
              position: 'center'
              });
        }, 2000);
    </script>
    <?php
    }
}

//################################################################################## check user exists on pages open

function checkUserAuthOnPage() 
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    $table_name = "appUsers";
    $select="*";
    $where="WHERE username='".$_GET["clt_username"]."' AND  password='".$_GET["clt_password"]."' AND  phoneID='".$_GET["clt_phoneID"]."'  ";
    $result = DBSelect($table_name, $select, $where);
    
    if (mysqli_num_rows($result) < 1)
    {
    echo '
    <div class="padding border-red-800 red-100 shadow radius">
      <p style="text-align: center;">
      <b>INFO !</b><br>
      Si vous n\'avez pas de compte, <br>appuyez sur le bouton suivant:<br>
      <button class="blue text-white border-red-800 radius small" onclick="openPage(\'createAccount\');" > S\'inscrire</button><br>
      <br>
      Vous avez déjà un compte ? <br>Veuillez appuyez sur ce bouton ci:<br>
      <button class="green text-white border-red-800 radius small" onclick="openPage(\'paramAccount\');" > Se connecter</button><br>
      </p>
    </div>
    ';
    exit;
    }
}

//########################################################################## get livret data

function getLivretData($numLivretX)
{
    $table_name = "appLivret";
    $select="*";
    $where="WHERE numLivret='".$numLivretX."' ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
        $row = mysqli_fetch_assoc($result);
        $logDateTime = $row["logDateTime"];
        $moisAnnLivret = $row["moisAnnLivret"];
        ?>

            <div class="border-red-800 mark shadow radius margin-bottom" style="padding-bottom: 2px;" onclick="openLivret('<?php echo $moisAnnLivret; ?>');">
                <div class="row">
                  <div class="col-75" style="padding: 5px;">
                  <p class="text-black" style="font-weight: bold; font-size: 5.5vw;"><?php echo $row["textMoisAnnLivret"]; ?></p>
                  <p class="text-red" style="font-weight: bold; font-size: 4vw;"><?php echo "Livret N° ".$row["numLivret"]." - ".$row["annLivret"]; ?></p>
                  </div>
                  <div class="col-25 align-center">
                    <img width="75%" src="img/edition.png">
                  </div>
                </div>
                <p><img src="<?php echo $row["imgLivret"]; ?>" width="100%"></p>
                <p class="text-grey" style="font-size: 3.5vw; padding-left: 5px;">Cliquez pour voir le contenu</p>
            </div>

        <?php
	    }
}

//########################################################################## get post data

function getPostData($idPostX)
{
    $table_name = "appLivretText";
    $select="*";
    $where="WHERE id_post='".$idPostX."' ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{

        $row = mysqli_fetch_assoc($result);
            ?>
                    <div class="item no-border">
                          <div style="padding: 5px;">
                              <p class="text-black align-center" style="font-weight: bold; font-size: 6vw;"><?php echo $row["date_text"]; ?></p>
                              <p class="text-grey align-center" style="font-size: 4.5vw;"><?php echo $row["textSemTempsLiturg"]; ?></p>
                              <p class="text-blue align-center" style="font-size: 5vw;"><?php echo $row["nom_saint"]; ?></p>
                              <p >
                                <img src="<?php echo $row["img_post"]; ?>" width="100%" class="radius">
                              </p>
                              <br>
                          </div>
                          <p class="text-black" style="font-size: 5vw; text-align: justify;" id="textContent"></p>
                    </div>
                    <script> 
                        closeLoading();
                        $("#textContent").load("<?php echo $row["text_post"]; ?>");
                    </script>
            <?php
    }
}

//########################################################################## find moisAnn livret using numLivret

function findUserMaxMonthACL($numLivretX)
{
    $table_name = "appLivret";
    $select="*";
    $where="WHERE numLivret='".$numLivretX."' ";
    $result = DBSelect($table_name, $select, $where);
    
    if (mysqli_num_rows($result) > 0)
    {
        $row = mysqli_fetch_assoc($result);
        return $row["textMoisAnnLivret"];
    }
    else
    {
        echo "Livret N° ".$numLivretX;
    }
}

//########################################################################## get user highest month acces in ACL

function getUserMaxNumLivretACL($userX)
{
    $table_namePay = "appLivretACL";
    $selectPay="*";
    
    $wherePay="WHERE username='".$userX."' "; 
    $resultPay = DBSelect($table_namePay, $selectPay, $wherePay);

    $rowPay = mysqli_fetch_assoc($resultPay);
    $typACL = $rowPay["typACL"];

    if ($typACL === 'Premium') 
    {
      echo 'Accès Premium';
    }
    else
    {
      $numLivretList = $rowPay["numLivret"];
      $numLivretListExploded=explode(',',$numLivretList);
      $maxNumLivret= 0;

      foreach ($numLivretListExploded as $numLivret)
      {
          if($numLivret > $maxNumLivret) {$maxNumLivret=$numLivret;}
      }

      $userMaxMonthACL = findUserMaxMonthACL($maxNumLivret);
      echo $userMaxMonthACL;
    }
    
    //echo $maxNumLivret;
}

//########################################################################## find livret blue parts

function findMonthLivretBlueTitle($monthAnnX)
{
    $table_name = "appLivret";
    $select="*";
    $where="WHERE moisAnnLivret='".$monthAnnX."' ";
    $result = DBSelect($table_name, $select, $where);

        $row = mysqli_fetch_assoc($result);
        echo $row["bluePartlivret"];
}

//########################################################################## find livret red parts

function findMonthLivretRedTitle($monthAnnX)
{
    $table_name = "appLivret";
    $select="*";
    $where="WHERE moisAnnLivret='".$monthAnnX."' ";
    $result = DBSelect($table_name, $select, $where);

        $row = mysqli_fetch_assoc($result);
        echo $row["redPartlivret"];
}

//###################################################################### check if exist

function checkifDmdExist($tabx, $val1, $val2)
{
    $select="*";
    $where="WHERE username='".$val1."' AND logDate='".$val2."' ";
    $result = DBSelect($tabx, $select, $where);

    if (mysqli_num_rows($result) > 0)
    {
        echo '111';
        exit;
    }
}

//###################################################################### check if exist

function newUserToACL($xuser, $xfullname, $xDT)
{
      $table_name = "appLivretACL";

      $form_data = array(
      'username' => inputSanitize($xuser),
      'nom' => inputSanitize($xfullname),
      'typACL' => 'Normal',
      'numLivret' => '226',
      'logDateTime' => $xDT
      );
      
      list($result, $insertedID) = DBInsert($table_name, $form_data);

      
      // if ($result)
      // {
      //     echo '1'; 
      // }
      // else 
      // {
      //     echo '0'; 
      // }
}

//########################################################################## check user creds

if($op == "checkUserAuth")
{
    checkUserAuth();
}

//########################################################################## create new user account

if($op == "createUserAuth")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    $table_name = "appUsers";
    $select="*";
    $where="WHERE username='".$_GET["clt_username"]."' ";
    $xresult = DBSelect($table_name, $select, $where);

    $clt_username = $_GET["clt_username"];
    $clt_nom = $_GET["clt_nom"];

    if (mysqli_num_rows($xresult) < 1)
    {
            $form_data = array(
            'username' => checkEmptyInput($_GET["clt_username"]),
            'password' => checkEmptyInput($_GET["clt_password"]),
            'nom' => checkEmptyInput($_GET["clt_nom"]),
            'email' => inputSanitize($_GET["clt_email"]),
            'pays' => checkEmptyInput($_GET["clt_pays"]),
            'phoneID' => checkEmptyInput($_GET["clt_phoneID"]),
            'refPushNotif' => inputSanitize($_GET["refPushNotif"]),
            'logDateTime' => $dateTimeNow
           );
           
  
           list($result, $insertedID) = DBInsert($table_name, $form_data);
           
            if ($result)
            {
               echo '1';
               newUserToACL($clt_username, $clt_nom, $dateTimeNow);
            }
            else 
            {
               echo '0'; 
            }
    }
    else
    {
    echo '10';
    exit;
    }
}

//########################################################################## listing my profil info

if($op == "showMyProfilInfos")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $clt_username = $_GET["clt_username"];
    $table_name = "appUsers";
    $select="*";
    
    $where="WHERE username='".$clt_username."' "; 
    $result = DBSelect($table_name, $select, $where);

    if (mysqli_num_rows($result) > 0)
	{
            $row = mysqli_fetch_assoc($result);
            ?>
            <div class="list">
                
              <div class="item space-small">
                <div class="left">
                  <i class="icon ion-person" style="font-size: 10vw;"></i>
                </div>
                <p class="text-grey-500">Nom et Prenoms :</p>
                <h2 class="text-blue text-strong"><?php echo strtoupper($row["nom"]); ?></h2>
              </div>
              <div class="item space-small">
                <div class="left">
                  <i class="icon ion-email" style="font-size: 10vw;"></i>
                </div>
                <p class="text-grey-500">E-mail :</p>
                <h2 class="text-blue text-strong"><?php echo $row["email"]; ?></h2>
              </div>
              <div class="item space-small">
                <div class="left">
                  <i class="icon ion-android-globe" style="font-size: 10vw;"></i>
                </div>
                <p class="text-grey-500">Pays de résidence :</p>
                <h2 class="text-blue text-strong"><?php echo $row["pays"]; ?></h2>
              </div>
              <div class="item space-small">
                <div class="left">
                  <i class="icon ion-ios-telephone" style="font-size: 10vw;"></i>
                </div>
                <p class="text-grey-500">Numero de téléphone :</p>
                <h2 class="text-blue text-strong"><?php echo $row["username"]; ?></h2>
              </div>
              <div class="item space-small">
                <div class="left">
                  <i class="icon ion-locked" style="font-size: 10vw;"></i>
                </div>
                <p class="text-grey-500">Mot de passe :</p>
                <h2 class="text-blue text-strong"><?php echo $row["password"]; ?></h2>
              </div>
              <div class="item space-small">
                <div class="left">
                  <i class="icon ion-ios-timer-outline" style="font-size: 10vw;"></i>
                </div>
                <p class="text-grey-500">Fin d'abonnement :</p>
                <h2 class="text-blue text-strong"><?php getUserMaxNumLivretACL($clt_username); ?></h2>
              </div>
            </div>
            <div class="space"></div>
            <div class="padding border-blue-800 blue-100 shadow radius">
              <p style="text-align: center;">
              <b>INFO !</b><br>
                  Votre compte est unique et lié à votre téléphone.
                  Si vous désirez modifier des données de votre compte et continuer à l'utiliser ce compte sur ce téléphone, appuyez sur le bouton.<br>
                  <button class="yellow text-black border-red-800 radius small" onclick="openPage('changeProfilInfo')" > Modification Profil</button><br>
              </p>
            </div>
            <div class="space"></div>
            <?php
	}
}

//########################################################################## listing my livrets

if($op == "listMyLivrets")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $clt_username = $_GET["clt_username"];
    $table_namePay = "appLivretACL";
    $selectPay="*";
    
    $wherePay="WHERE username='".$clt_username."' ORDER BY id DESC"; 
    $resultPay = DBSelect($table_namePay, $selectPay, $wherePay);

    if (mysqli_num_rows($resultPay) > 0)
    {
              $rowPay = mysqli_fetch_assoc($resultPay);
              $numLivretList = $rowPay["numLivret"];
              $numLivretListExploded=explode(',',$numLivretList);
              
              foreach ($numLivretListExploded as $numLivret)
              {
              getLivretData($numLivret);
              }
    }
    else
    {
      echo '
      <div class="margin padding border-yellow-800 yellow-100 shadow radius">
        <p style="text-align: center;">
        <b>INFO !</b><br> 
        Vous n\'avez aucun abonnement valide.<br>
        Si vous désirez avoir accès aux Livrets,<br>
        appuyez sur le bouton suivant. <br>
        <button class="yellow text-black border-red-800 radius small" onclick="backPage(); openPage(\'abonner\');" > S\'abonner</button><br>
        </p>
      </div>
      ';
	}

}

//################################################################################ open livret

if($op == "openLivret")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $moisAnnLivret=$_GET["moisAnnLivret"];
    $table_name = "appLivretText";
    $select="*";
    $where="WHERE moisAnnLivret='".$moisAnnLivret."' ORDER BY id_post ASC ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
		    ?>
		      <div class="padding border-blue blue-50 shadow radius mark margin-bottom" onclick="openLivretExtra('<?php echo $moisAnnLivret; ?>')">
              <ul style="list-style-type:square; text-transform: uppercase; padding-left: 10px;" >
                <?php findMonthLivretBlueTitle($moisAnnLivret); ?>
              </ul>
          </div>
          <div class="padding border-red-800 red-50 shadow radius mark margin-bottom" onclick="openLivretExtraRed('<?php echo $moisAnnLivret; ?>')">
              <ul style="list-style-type:square; text-transform: uppercase; padding-left: 10px;" >
                <?php findMonthLivretRedTitle($moisAnnLivret); ?>
              </ul>
          </div>
		    <?php
            while($row = mysqli_fetch_assoc($result))
            {
            $logDateTime = $row["logDateTime"];
            ?>

            <div class="item border-blue-grey-200 shadow radius margin-bottom" onclick="openPost('<?php echo $row["id_post"]; ?>');">
                <div class="row">
                  <div class="col-80" style="padding:5px;">
                      <p class="text-black" style="font-weight: bold; font-size: 4.5vw;"><?php echo $row["date_text"]; ?></p>
                      <p class="text-black" style="font-size: 3.5vw;"><?php echo $row["textSemTempsLiturg"]; ?></p>
                      <p class="text-blue" style="font-size: 3.5vw;"><?php echo $row["nom_saint"]; ?></p>
                  </div>
                  <div class="col-20 align-center">
                    <img width="75%" src="img/edition.png">
                  </div>
                </div>
                <p>
                    <img src="<?php echo $row["img_post"]; ?>" width="100%">
                </p>
                <p class="text-black" style="font-weight: bold;font-size: 3.5vw; padding-left: 5px;"><?php echo $row["ref_evang"]; ?></p>
                <p class="text-red-800" style="font-size: 3.5vw; padding-left: 5px;">Cliquez pour voir le contenu</p>
            </div>
            <script> 
                    closeLoading(); // This will hide ajax spinner 
                    $('#titleMonth').html("<?php echo ucfirst(monthYearFormatToFR($row["moisAnnLivret"])); ?>");
            </script>
            
            <?php
            }

	    }
        else 
        {
        echo '
        <div class="padding border-blue-800 blue-100 shadow radius">
          <p style="text-align: center;">
          <b>INFO !</b><br>
          Votre abonnement est bien valide,<br>
          mais le contenu de ce Livret n\'est pas encore disponible.<br>
          <b>Merci</b>
          </p>
        </div>
        ';
        }
}

//################################################################################ open livret Extra Blue

if($op == "openLivretExtra")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $moisAnnLivret=$_GET["moisAnnLivret"];
    $table_name = "appLivret";
    $select="*";
    $where="WHERE moisAnnLivret='".$moisAnnLivret."' ";

    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
        $row = mysqli_fetch_assoc($result);
            ?>
            <div class="text-black" style="font-size: 5vw; text-align: justify;" id="textContent"></div>
            <script> 
                //closeLoading(); // This will hide ajax spinner 
                $('#titleMonthExtra').html("<?php echo ucfirst(monthYearFormatToFR($moisAnnLivret)); ?>");
                $('#textContent').load('<?php echo $row["textLivret"]." #blue"; ?>');
            </script>
            <?php
	    }
        else 
        {
        echo '
        <div class="padding border-blue-800 blue-100 shadow radius">
          <p style="text-align: center;">
          <b>INFO !</b><br>
          Votre abonnement est bien valide,<br>
          mais le contenu de ce Livret n\'est pas encore disponible.<br>
          <b>Merci</b>
          </p>
        </div>
        ';
        }
}

//################################################################################ open livret Extra Red

if($op == "openLivretExtraRed")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $moisAnnLivret=$_GET["moisAnnLivret"];
    $table_name = "appLivret";
    $select="*";
    $where="WHERE moisAnnLivret='".$moisAnnLivret."' ";

    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
        $row = mysqli_fetch_assoc($result);
            ?>
            <div class="text-black" style="font-size: 5vw; text-align: justify;" id="textContent"></div>
            <script> 
                //closeLoading(); // This will hide ajax spinner 
                $('#titleMonthExtra').html("<?php echo ucfirst(monthYearFormatToFR($moisAnnLivret)); ?>");
                $('#textContent').load('<?php echo $row["textLivret"]." #red"; ?>');
            </script>
            <?php
	    }
        else 
        {
        echo '
        <div class="padding border-blue-800 blue-100 shadow radius">
          <p style="text-align: center;">
          <b>INFO !</b><br>
          Votre abonnement est bien valide,<br>
          mais le contenu de ce Livret n\'est pas encore disponible.<br>
          <b>Merci</b>
          </p>
        </div>
        ';
        }
}

//################################################################################ open post

if($op == "openPost")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $table_name = "appLivretText";
    $select="*";
    $where="WHERE id_post='".$_GET["idPost"]."' ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
            $row = mysqli_fetch_assoc($result);
            ?>
                    <div class="item no-border">
                          <div style="padding: 5px;">
                              <p class="text-black align-center" style="font-weight: bold; font-size: 6vw;"><?php echo $row["date_text"]; ?></p>
                              <p class="text-grey align-center" style="font-size: 4.5vw;"><?php echo $row["textSemTempsLiturg"]; ?></p>
                              <p class="text-blue align-center" style="font-size: 5vw;"><?php echo $row["nom_saint"]; ?></p>
                              <p >
                                <img src="<?php echo $row["img_post"]; ?>" width="100%" class="radius">
                              </p>
                              <br>
                          </div>
                          <p class="text-black" style="font-size: 5vw; text-align: justify;" id="textContent"></p>
                    </div>
                    <script> 
                        closeLoading();
                        $("#textContent").load("<?php echo $row["text_post"]; ?>");
                    </script>
            <?php
	    }
        else 
        {
        echo '
        <div class="margin padding border-blue-800 blue-100 shadow radius">
          <p style="text-align: center;">
          <b>INFO !</b><br>
          Votre abonnement est bien valide,<br>
          mais le contenu de ce jour n\'est pas encore disponible.<br>
          <b>Merci</b>
          </p>
        </div>
        ';
        }

}

//########################################################################## listing today post

if($op == "listTodayPost")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $table_name = "appLivretText";
    $select="*";
    $where="WHERE todayDate='".$todayDate."' ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
            $row = mysqli_fetch_assoc($result);
            $numLivretAndIdPost = $row["numLivret"].'-'.$row["id_post"];
            ?>
                <p class="text-grey align-center" style="font-weight: bold; font-size: 12px;">Lectures du jour</p>
                <div class="padding border-grey-400 shadow radius" onclick="openTodayPost('<?php echo $numLivretAndIdPost; ?>');">
                <div class="row">
                  <div class="col-80">
                      <p class="text-black" style="font-weight: bold; font-size: 4vw;"><?php echo $row["date_text"]; ?></p>
                      <p class="text-black" style="font-size: 3.5vw;"><?php echo $row["textSemTempsLiturg"]; ?></p>
                      <p class="text-blue" style="font-size: 3.5vw;"><?php echo $row["nom_saint"]; ?></p>
                  </div>
                  <div class="col-20 align-center">
                    <img class="avatar" width="75%" src="img/edition.png">
                  </div>
                </div>
                <p><img src="<?php echo $row["img_post"]; ?>" width="100%" class="radius"></p>
                <p class="text-black" style="font-weight: bold;font-size: 3.5vw; padding-left: 5px;"><?php echo $row["ref_evang"]; ?></p>
                <p class="text-red-800" style="font-size: 3vw;">Cliquez pour voir le contenu </p>
                </div>

            <?php

	    }
        else 
        {
        echo '
        <div class="padding border-blue-800 blue-100 shadow radius">
          <p style="text-align: center;">
          <b>INFO !</b><br>
          Le texte de ce jour n\'est pas encore disponible.<br>
          <b>Merci</b>
          </p>
        </div>
        <p class="text-grey align-center" onclick="getTodayPost()" style="font-size: 4vw; padding: 20px;">
          Actualiser<br>
          <i class="icon ion-ios-loop text-grey" style="font-size: 15vw;"></i>
        </p>
        ';
        }

}

//################################################################################ open last post

if($op == "openTodayPost")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $usernameToCheck = $_GET["clt_username"];
    $numLivretAndIdPost = $_GET["numLivretAndIdPost"];
    $numLivretAndIdPostExploded=explode('-',$numLivretAndIdPost);
    $numLivretToOpen = $numLivretAndIdPostExploded[0];
    $idPostToOpen = $numLivretAndIdPostExploded[1];


    $table_namePay = "appLivretACL";
    $selectPay="*";
    
    $wherePay="WHERE username='".$usernameToCheck."' "; 
    $resultPay = DBSelect($table_namePay, $selectPay, $wherePay);

    if (mysqli_num_rows($resultPay) > 0)
    {
              $rowPay = mysqli_fetch_assoc($resultPay);
              $numLivretList = $rowPay["numLivret"];
              $numLivretListExploded=explode(',',$numLivretList);
              
              if (in_array($numLivretToOpen, $numLivretListExploded, true ))
              {
                getPostData($idPostToOpen);
              }
              else
              {
                echo '
                    <div class="margin padding border-yellow-800 yellow-100 shadow radius">
                      <p style="text-align: center;">
                      <b>INFO !</b><br> 
                      Vous n\'avez pas d\'abonnement pour le mois actuel.
                      Si vous désirez avoir accès au Livret du mois courant, 
                      appuyez sur le bouton suivant <br>
                      <button class="yellow text-black border-red-800 radius small" onclick="backPage(); openPage(\'abonner\');" > S\'abonner</button><br>
                      </p>
                    </div>
                    ';
              }
    }
    else
    {
      echo '
      <div class="margin padding border-yellow-800 yellow-100 shadow radius">
        <p style="text-align: center;">
        <b>INFO !</b><br> 
        Vous n\'avez pas d\'abonnement pour le mois actuel.
        Si vous désirez avoir accès au Livret du mois courant, 
        appuyez sur le bouton suivant <br>
        <button class="yellow text-black border-red-800 radius small" onclick="backPage(); openPage(\'abonner\');" > S\'abonner</button><br>
        </p>
      </div>
      ';
    }

}

//########################################################################## create change phone request

if($op == "changePhone")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    $table_name = "appChangePhone";
    
    $usernamePhone = $_GET["usernamePhone"];
    $passwordPhone = $_GET["passwordPhone"];
    $nomPhone = $_GET["nomPhone"];
    $clt_phoneID = $_GET["clt_phoneID"];
    $refPushNotif = $_GET["refPushNotif"];
    
    checkifDmdExist($table_name, $usernamePhone, $todayDate);
    
    $body ='Notif-Dmd-Chgmt-Phone <br>
            Username: '.$usernamePhone.' <br>
            Pass: '.$passwordPhone.' <br>
            Nom: '.$nomPhone.' <br>
            Phone uuid: '.$clt_phoneID.' <br>
            FCM: '.$refPushNotif.' ';

        $form_data = array(
        'username' => checkEmptyInput($usernamePhone),
        'password' => checkEmptyInput($passwordPhone),
        'nom' => checkEmptyInput($nomPhone),
        'phoneID' => checkEmptyInput($clt_phoneID),
        'refPushNotif' => checkEmptyInput($refPushNotif),
        'logDate' => $todayDate,
        'logDateTime' => $dateTimeNow
       );

       list($result, $insertedID) = DBInsert($table_name, $form_data);
       
        if ($result)
        {
           echo '1';
           require 'PHPMailer/mailSender.php';
           phpSendMail("fridoehon@gmail.com", "Notif-Dmd-Chgmt-Phone", $body);  
        }
        else 
        {
           echo '0'; 
        }

}

//########################################################################## create change profil request

if($op == "changeProfil")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
	
    $table_name = "appChangeProfil";
    
    $cltUsername = $_GET["clt_username"];
    $motif = $_GET["motifModifProfil"];
    $newValues = $_GET["dataModifProfil"];
    
    checkifDmdExist($table_name, $cltUsername, $todayDate);
    
    $body ='Notif-Dmd-Chgmt-Profil <br>
            Username: '.$cltUsername.' <br>
            Motif: '.$motif.' <br>
            NewValues: '.$newValues.' ';

        $form_data = array(
        'username' => checkEmptyInput($cltUsername),
        'motif' => checkEmptyInput($motif),
        'newVal' => checkEmptyInput($newValues),
        'logDate' => $todayDate,
        'logDateTime' => $dateTimeNow
       );
       

       list($result, $insertedID) = DBInsert($table_name, $form_data);
       
        if ($result)
        {
           echo '1';
            require 'PHPMailer/mailSender.php';
            phpSendMail("fridoehon@gmail.com", "Notif-Dmd-Chgmt-Profil", $body);  
        }
        else 
        {
           echo '0'; 
        }

}
