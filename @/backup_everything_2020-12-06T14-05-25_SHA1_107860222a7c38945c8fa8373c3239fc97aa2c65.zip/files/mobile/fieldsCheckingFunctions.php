<?php

////////////////////////////////////////////////

function inputSanitize($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  $data = addslashes($data);
  return $data;
}

////////////////////////////////////////////////

function checkEmptyInput($data) 
{
	if (empty($data)) 
	{
		?>
	  <div class="text-red no-margin no-padding">Erreur! Veuillez remplir les champs obligatoires et réessayez</div>
        <?php
		exit;
	}
	else 
	{
		$data =  inputSanitize($data);
		return $data;
	}
}

////////////////////////////////////////////////

function checkEmptyAuth($data) 
{
	if (empty($data)) 
	{
		?>
	  <div class="text-red no-margin no-padding">Erreur! Vérifiez vos données d'authentification</div>
	  <script>
			$("#uploadPictures").html("Valider");
      </script>
            <?php
		exit;
	}
	else 
	{
		$data =  inputSanitize($data);
		return $data;
	}
}

////////////////////////////////////////////////

function dateFormatToFR($data) 
{
	if (strlen($data) == 0 || $data == '0000-00-00' || is_null($data) )
	{
	$data = "N/A";
	}
	else 
	{
	$data = strtotime($data);
	//setlocale(LC_TIME, "fr_FR.utf8", "fra");
	setlocale(LC_TIME, 'fr_FR');
	$data = strftime("%d %B %Y %H:%M:%S",$data);
	}
	return utf8_encode($data);
	return $data;
}

////////////////////////////////////////////////

function monthYearFormatToFR($data) 
{
	if (strlen($data) == 0 || $data == '00-0000' || is_null($data) )
	{
	$data = "N/A";
	}
	else 
	{
	$data = explode("-", $data);
	//setlocale(LC_TIME, "fr_FR.utf8", "fra");
	setlocale(LC_TIME, 'fr_FR');
	$data = strftime("%B", mktime(0, 0, 0, $data[0], 10))." $data[1]";
	}
	return utf8_encode($data);
	return $data;
}

////////////////////////////////////////////////

function checkEmail($data) 
{
	if (!filter_var($data, FILTER_VALIDATE_EMAIL)) 
	{
	echo "
	<div class=\"alert alert-danger alert-dismissable\">
		<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">×</a>
	  	<strong>Erreur!</strong>  Veuillez corriger votre email et reessayez.
	</div>
	";
	exit;
	} 
}

////////////////////////////////////////////////

function checkNumber($data) 
{
	if (!preg_match("/^[0-9]+$/i", $data)) 
	{
	echo "Veuillez ecrire correctemenet le numero de telephone";
	exit;
	}  
}

////////////////////////////////////////////////

function qteToTonn($data) 
{
	if (strpos($data, '.'))
	{
	  $data = ROUND($data,3);
	  $data = number_format($data,3,"."," ");
	  echo $data; 
	}
	  
	if (!strpos($data, '.'))
	{
	  $data = number_format($data,0,"."," ");
	  echo $data;
	}
}

////////////////////////////////////////////////

function priceFormatToCFA($data) 
{
  echo number_format($data,0,"."," ");
}

////////////////////////////////////////////////

function priceFormatToEURO($data) 
{
  echo number_format(ROUND($data,2),2,"."," ");
}

////////////////////////////////////////////////

function convertMonthYearToDateMonth($data) 
{
setlocale(LC_TIME, 'fr_FR');
$data = explode("-", $data);
$data = $data[1];
echo utf8_encode(strftime("%B", mktime(null, null, null, $data, 1)))." ";
}

////////////////////////////////////////////////

function convertMonthYearToDateYear($data) 
{
setlocale(LC_TIME, 'fr_FR');
$data = explode("-", $data);
echo $data[0];
}

////////////////////////////////////////////////

function getDBSuffix($data) 
{
$data = substr_replace($data,"",0,2);
$data = substr_replace($data,"",3,2);
$data = str_replace("/","",$data);
return $data;
}

?>