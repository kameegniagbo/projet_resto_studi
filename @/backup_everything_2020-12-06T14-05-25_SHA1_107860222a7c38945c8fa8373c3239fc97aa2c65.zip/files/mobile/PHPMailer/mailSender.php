<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// use PHPMailer\PHPMailer;
// use PHPMailer\Exception;

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

function phpSendMail($to, $subj, $msg1) 
{
        // Instantiation and passing `true` enables exceptions
        $mail = new PHPMailer(true);
        
        try {
            //Server settings
            //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
            $mail->SMTPDebug = 0;
            $mail->isSMTP();                                            // Send using SMTP
            // $mail->Host       = 'localhost';                    // Set the SMTP server to send through
            // $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            // $mail->Username   = 'admin@tkeva.online';                     // SMTP username
            // $mail->Password   = 'fri@PWD@007';                               // SMTP password
            // //$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
            // //$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            // $mail->SMTPSecure = 'ssl';
            // $mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

//############################# FOR GODADDY ###############################

$mail->Host = 'localhost'; // Specify main and backup SMTP servers
$mail->SMTPAuth = false; // Enable SMTP authentication
$mail->Username = ''; // SMTP username
$mail->Password = ''; // SMTP password
$mail->SMTPAutoTLS = false; 
$mail->SMTPSecure = false; // Enable TLS encryption, `ssl` also accepted
$mail->Port = 25;     

//#########################################################################

            //Recipients
            $mail->setFrom('admin@iron-technologies.com', 'ParoleDeVie');
            $mail->addAddress($to);     // Add a recipient
            // $mail->addAddress('ellen@example.com');               // Name is optional
            $mail->addReplyTo('admin@iron-technologies.com', 'ParoleDeVie');
            // $mail->addCC('cc@example.com');
            // $mail->addBCC('bcc@example.com');
        
            // Attachments
            // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
        
            // Content
            $mail->CharSet = 'UTF-8';
            $mail->isHTML(true);                                  // Set email format to HTML
    	    $mail->Subject = $subj;
    	    $mail->Body    = $msg1;
    	    $mail->AltBody = $msg1;
        
            $mail->send();
            // echo '
            // <div class="margin padding border-green-800 green-100 shadow radius">
            //   <p style="text-align: center;">
            //   Votre demande a été envoyée. Vous recevrez une confirmation dans peu de temps. <br><b>Merci</b>
            //   </p>
            // </div>';
        } catch (Exception $e) {
            //echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            echo "";
        }

}

?>