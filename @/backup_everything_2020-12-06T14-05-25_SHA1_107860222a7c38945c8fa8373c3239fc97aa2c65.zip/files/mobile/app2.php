<?php
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$todayDate = date('d-m-Y');
$thisMonthYear = date('m-Y');

//##################################################################################

if($_GET)
{
$op=$_GET["op"];
}

//################################################################################## check user exist

function checkUserAuth() {
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    $table_name = "appUsers";
    $select="*";
    $where="WHERE username='".$_GET["clt_username"]."' AND  password='".$_GET["clt_password"]."' AND  phoneID='".$_GET["clt_phoneID"]."'  ";
    $result = DBSelect($table_name, $select, $where);
    $row = mysqli_fetch_assoc($result);
    
    if (mysqli_num_rows($result) < 1)
    {
    //echo '0';
    ?>
    <script>
        openToast({
          message: 'compte erroné, inexistant ou déjà utilisé',
          class: 'red-800 radius-big',
          position: 'center'
        });
        $('#connectedUser').html("Erreur...");
    </script>
    <?php
    exit;
    }
    else
    {
    //echo '1';
    ?>
    <script>
        $('#connectedUser').html("N° connecté: " + "<?php echo $row["username"]; ?>");
        closeLoading(); // This will hide ajax spinner
    </script>
    <?php
    }
}


if($op == "checkUserAuth")
{
    checkUserAuth();
}

//################################################################################## check user exists on pages open

function checkUserAuthOnPage() 
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    $table_name = "appUsers";
    $select="*";
    $where="WHERE username='".$_GET["clt_username"]."' AND  password='".$_GET["clt_password"]."' AND  phoneID='".$_GET["clt_phoneID"]."'  ";
    $result = DBSelect($table_name, $select, $where);
    
    if (mysqli_num_rows($result) < 1)
    {
    echo '
    <div class="padding border-red-800 red-100 shadow radius">
      <p style="text-align: center;">
      Le compte que vous essayez d\'utiliser est soit inexistant, soit déjà utilisé sur un autre téléphone.
      Si vous n\'avez pas de compte, appuyez sur le bouton <b>Mon Compte</b> ensuite sur le bouton jaune <b>Inscrivez-vous</b>.
      Après avoir créer votre compte, vous devez vous <b>Acheter Livret</b> pour avoir accès au Livret et aux autres services.
      </p>
    </div>
    ';
    exit;
    }
}

//########################################################################## get livret data

function getLivretData($numLivretX)
{
    $table_name = "appLivret";
    $select="*";
    $where="WHERE numLivret='".$numLivretX."' ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
        $row = mysqli_fetch_assoc($result);
        $logDateTime = $row["logDateTime"];
        $moisAnnLivret = $row["moisAnnLivret"];
        ?>

            <div class="border-blue-800 shadow radius margin-bottom mark" style="padding-bottom: 2px;" onclick="openLivret('<?php echo $moisAnnLivret; ?>');">
                <div class="row">
                      <div class="col-75 padding">
                      <p class="text-black" style="font-weight: bold; font-size: 5.5vw;"><?php echo $row["textMoisAnnLivret"]; ?></p>
                      <p class="text-blue" style="font-weight: bold; font-size: 4.5vw;"><?php echo "Livret N° ".$row["numLivret"]; ?></p>
                      </div>
                      <div class="col-25 align-center">
                        <img class="avatar" width="75%" src="img/edition.png">
                      </div>
                </div>
                <p><img src="<?php echo $row["imgLivret"]; ?>" width="100%"></p>
                <p class="text-black" style="font-weight: bold;font-size: 12px;"><?php echo $row["annLivret"]; ?></p>
                <p class="text-blue-800" style="font-size: 3.5vw; padding-left: 10px;">Cliquez pour voir le contenu</p>
            </div>

        <?php
	    }
        else 
        {
        echo '
        <div class="padding border-yellow-800 yellow-100 shadow radius">
          <p style="text-align: center;">
          <b>INFO !</b><br>
          Si vous désirez avoir accès à d\'autres Livrets, 
          retournez sur la page d\'Accueil, appuyez sur le bouton <b>Acheter Livret</b> 
          puis selectionnez le mois désiré et procédez au paiement.<br>
          <b>Merci</b>
          </p>
        </div>
        ';
        }

}

//########################################################################## create new user account

if($op == "createUserAuth")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    $table_name = "appUsers";
    $select="*";
    $where="WHERE username='".$_GET["clt_username"]."' ";
    $xresult = DBSelect($table_name, $select, $where);

    if (mysqli_num_rows($xresult) < 1)
    {
            $form_data = array(
            'username' => checkEmptyInput($_GET["clt_username"]),
            'password' => checkEmptyInput($_GET["clt_password"]),
            'nom' => checkEmptyInput($_GET["clt_nom"]),
            'pays' => checkEmptyInput($_GET["clt_pays"]),
            'phoneID' => checkEmptyInput($_GET["clt_phoneID"]),
            'refPushNotif' => checkEmptyInput($_GET["refPushNotif"]),
            'logDateTime' => $dateTimeNow
           );
           
  
           list($result, $insertedID) = DBInsert($table_name, $form_data);
           
            if ($result)
            {
               echo '1'; 
            }
            else 
            {
               echo '0'; 
            }
    }
    else
    {
    echo '10';
    exit;
    }
}

//########################################################################## listing my livrets

if($op == "listMyLivrets")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $clt_username = $_GET["clt_username"];
    $table_namePay = "appLivretACL";
    $selectPay="*";
    
    $wherePay="WHERE username='".$clt_username."' ORDER BY id DESC"; 
    $resultPay = DBSelect($table_namePay, $selectPay, $wherePay);

    if (mysqli_num_rows($resultPay) > 0)
	{
            $rowPay = mysqli_fetch_assoc($resultPay);
            $numLivretList = $rowPay["numLivret"];
            $numLivretListExploded=explode(',',$numLivretList);
            
            foreach ($numLivretListExploded as $numLivret)
            {
            getLivretData($numLivret);
            }
                    
	}
	else
	{
    echo '
    <div class="padding border-yellow-800 yellow-100 shadow radius">
      <p style="text-align: center;">
      <b>Désolé !</b><br> 
      Vous n\'avez pas d\'abonnement ni aucun Livret acheté.
      Si vous désirez avoir accès aux Livrets, 
      retournez sur la page précédente, appuyez sur le bouton <b>Acheter Livret</b> 
      puis selectionnez le mois désiré et procédez au paiement.<br>
      <b>Merci</b>
      </p>
    </div>
    ';
	}

}

//################################################################################ open livret

if($op == "openLivret")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $table_name = "appLivretText";
    $select="*";
    $where="WHERE moisAnnLivret='".$_GET["moisAnnLivret"]."' ORDER BY id_post DESC ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
            while($row = mysqli_fetch_assoc($result))
            {
            $logDateTime = $row["logDateTime"];
            ?>

            <div class="item border-blue-800 shadow radius margin-bottom" onclick="openPost('<?php echo $row["id_post"]; ?>');">
                <div class="row">
                  <div class="col-80 padding">
                      <p class="text-black" style="font-weight: bold; font-size: 4vw;"><?php echo $row["date_text"]; ?></p>
                      <p class="text-black" style="font-size: 3.5vw;"><?php echo $row["textSemTempsLiturg"]; ?></p>
                      <p class="text-blue" style="font-size: 3.5vw;"><?php echo $row["nom_saint"]; ?></p>
                  </div>
                  <div class="col-20 align-center">
                    <img class="avatar" width="75%" src="img/edition.png">
                  </div>
                </div>
              <p>
                <img src="<?php echo $row["img_post"]; ?>" width="100%">
              </p>
              <p class="text-black" style="font-weight: bold;font-size: 3.5vw; padding-left: 10px;"><?php echo $row["ref_evang"]; ?></p>
              <p class="text-blue-800" style="font-size: 3vw; padding-left: 10px;">Cliquez pour voir le contenu</p>
            </div>
            <script> closeLoading(); // This will hide ajax spinner </script>
            
            <?php
            }

	    }
        else 
        {
        echo '
        <div class="padding border-blue-800 blue-100 shadow radius">
          <p style="text-align: center;">
          <b>INFO !</b><br>
          Votre abonnement est bien valide,<br>
          mais le contenu de ce Livret n\'est pas encore disponible.<br>
          <b>Merci</b>
          </p>
        </div>
        ';
        }

}

//################################################################################ open post

if($op == "openPost")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $table_name = "appLivretText";
    $select="*";
    $where="WHERE id_post='".$_GET["idPost"]."' ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
            while($row = mysqli_fetch_assoc($result))
            {
            ?>
                    <div class="item no-border" style="padding: 5px;">
                          <p class="text-black" style="font-weight: bold; font-size: 6vw;"><?php echo $row["date_text"]; ?></p>
                          <p class="text-blue" style="font-size: 5vw;"><?php echo $row["nom_saint"]; ?></p>
                          <p >
                            <img src="<?php echo $row["img_post"]; ?>" width="100%" class="radius">
                          </p>
                          <br>
                          <p class="text-black" style="font-size: 5vw; text-align: justify;" id="textContent"></p>
                    </div>
                    <script> 
                        closeLoading();
                        $("#textContent").load("<?php echo $row["text_post"]; ?>");
                    </script>
            <?php
            }

	    }
        else 
        {
        echo '
        <div class="margin padding border-blue-800 blue-100 shadow radius">
          <p style="text-align: center;">
          <b>Désolé !</b><br>
          Le contenu de ce jour n\'est pas encore disponible.<br>
          <b>Merci</b>
          </p>
        </div>
        ';
        }

}

//########################################################################## listing today post

if($op == "listTodayPost")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $table_name = "appLivretText";
    $select="*";
    $where="WHERE todayDate='".$todayDate."' ";
	   
    $result = DBSelect($table_name, $select, $where);
	
	if (mysqli_num_rows($result) > 0)
		{
            while($row = mysqli_fetch_assoc($result))
            {
            ?>
                <p class="text-grey align-center" style="font-weight: bold; font-size: 12px;">Lectures du jour</p>
                <div class="padding border-grey-400 shadow radius" onclick="openTodayPost('<?php echo $row["id_post"]; ?>');">
                <div class="row">
                  <div class="col-80">
                      <p class="text-black" style="font-weight: bold; font-size: 4vw;"><?php echo $row["date_text"]; ?></p>
                      <p class="text-black" style="font-size: 3.5vw;"><?php echo $row["textSemTempsLiturg"]; ?></p>
                      <p class="text-blue" style="font-size: 3.5vw;"><?php echo $row["nom_saint"]; ?></p>
                  </div>
                  <div class="col-20 align-center">
                    <img class="avatar" width="75%" src="img/edition.png">
                  </div>
                </div>
                <p><img src="<?php echo $row["img_post"]; ?>" width="100%" class="radius"></p>
                <p class="text-blue-800" style="font-size: 3vw;">Cliquez pour voir le contenu</p>
                </div>

            <?php
            }

	    }
        else 
        {
        echo "Aucune donnée trouvée";
        }

}

//################################################################################ open last post

if($op == "openTodayPost")
{
	require_once("crudFunctions.php");
	require_once("fieldsCheckingFunctions.php");
    
    checkUserAuthOnPage();

    $postToOpen = $_GET["idPost"];
    $usernameToCheck = $_GET["clt_username"];

    $table_namePay = "appLivretPay";
    $selectPay="*";
    $wherePay="WHERE username='".$usernameToCheck."' AND moisAnnLivret='".$thisMonthYear."' "; 
    $resultPay = DBSelect($table_namePay, $selectPay, $wherePay);

    if (mysqli_num_rows($resultPay) > 0)
	{
                $table_name = "appLivretText";
                $select="*";
                $where="WHERE id_post='".$postToOpen."' ";
            	   
                $result = DBSelect($table_name, $select, $where);
            	
            	if (mysqli_num_rows($result) > 0)
            		{
                        while($row = mysqli_fetch_assoc($result))
                        {
                        ?>
        
                            <div class="item no-border" style="padding: 5px;">
                                  <p class="text-black" style="font-weight: bold; font-size: 6vw;"><?php echo $row["date_text"]; ?></p>
                                  <p class="text-blue" style="font-size: 5vw;"><?php echo $row["nom_saint"]; ?></p>
                                  <p class="text-blue-800">
                                    <img src="<?php echo $row["img_post"]; ?>" width="100%" class="radius">
                                  </p>
                                  <br>
                                  <div class="text-black" style="text-align: justify;" id="textContent"></div>
                            </div>
                            <script> 
                                closeLoading();
                                $("#textContent").load("<?php echo $row["text_post"]; ?>");
                            </script>
                        <?php
                        }
            
            	    }
                    else 
                    {
                    echo "Aucune donnée trouvée";
                    }
	}
	else
	{
	   echo '
        <div class="margin padding border-yellow-800 yellow-100 shadow radius">
          <p style="text-align: center;">
          <b>INFO !</b><br> 
          Vous n\'avez pas payé de Livret pour le mois actuel.
          Si vous désirez avoir accès au Livret du mois courant, 
          retournez sur la page précédente, appuyez sur le bouton <b>Acheter Livret</b> 
          puis selectionnez le mois actuel et procédez au paiement.<br>
          <b>Merci</b>
          </p>
        </div>
        ';
	}

}