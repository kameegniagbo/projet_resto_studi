<?php
	// Connect to database
	include("db_connect.php");
	date_default_timezone_set('UTC');
	$request_method = $_SERVER["REQUEST_METHOD"];
	$table = "appLivretText";

	function getAllData()
	{
		global $conn;
		global $table;
		$query = "SELECT * FROM ".$table." ORDER BY id DESC";
		$response = array();
		$result = mysqli_query($conn, $query);
		while($row = mysqli_fetch_assoc($result))
		{
			$response[] = $row;
		}
		header('Content-Type: application/json');
		echo json_encode($response, JSON_PRETTY_PRINT);
	}
	
	function getData($id=0)
	{
		global $conn;
		global $table;
		$query = "SELECT * FROM ".$table;
		if($id != 0)
		{
			$query .= " WHERE id=".$id." LIMIT 1";
		}
		$response = array();
		$result = mysqli_query($conn, $query);
		while($row = mysqli_fetch_assoc($result))
		{
			$response[] = $row;
		}
		header('Content-Type: application/json');
		echo json_encode($response, JSON_PRETTY_PRINT);
	}
	
	function addData()
	{

        $img1_path = "../appImages/imgSlide1.jpg";
        $img2_path = "../appImages/imgSlide2.jpg";
        $img3_path = "../appImages/imgSlide3.jpg";
        $img4_path = "../appImages/imgSlide4.jpg";
        $img5_path = "../appImages/imgSlide5.jpg";
        
        if(isset($_FILES["img1"]) && !empty($_FILES["img1"])) { move_uploaded_file($_FILES['img1']['tmp_name'], $img1_path); }
        if(isset($_FILES["img2"]) && !empty($_FILES["img2"])) { move_uploaded_file($_FILES['img2']['tmp_name'], $img2_path); }
        if(isset($_FILES["img3"]) && !empty($_FILES["img3"])) { move_uploaded_file($_FILES['img3']['tmp_name'], $img3_path); }
        if(isset($_FILES["img4"]) && !empty($_FILES["img4"])) { move_uploaded_file($_FILES['img4']['tmp_name'], $img4_path); }
        if(isset($_FILES["img5"]) && !empty($_FILES["img5"])) { move_uploaded_file($_FILES['img5']['tmp_name'], $img5_path); }

    // 		if(mysqli_query($conn, $query))
    // 		{
    // 			$insert_id = mysqli_insert_id($conn);
    // 			$response=array(
    // 				'status' => 1,
    // 				'status_message' =>'Donnees ajoutees avec succes #'.$insert_id
    // 			);
    // 		}
    // 		else
    // 		{
    // 			$response=array(
    // 				'status' => 0,
    // 				'status_message' =>'ERREUR!.'. mysqli_error($conn)
    // 			);
    // 		}
    // 		header('Content-Type: application/json');
    // 		echo json_encode($response);

	}
	
	function updateData($id)
	{
		global $conn;
		global $table;
		$_PUT = array();
		parse_str(file_get_contents('php://input'), $_PUT);
		$name = $_PUT["name"];
		$description = $_PUT["description"];
		$price = $_PUT["price"];
		$category = $_PUT["category"];
		$created = 'NULL';
		$modified = date('Y-m-d H:i:s');
		$query="UPDATE ".$table." SET name='".$name."', description='".$description."', price='".$price."', category_id='".$category."', modified='".$modified."' WHERE id=".$id;
		
		if(mysqli_query($conn, $query))
		{
			$response=array(
				'status' => 1,
				'status_message' =>'Produit mis a jour avec succes.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'status_message' =>'Echec de la mise a jour de produit. '. mysqli_error($conn)
			);
			
		}
		
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	function deleteData($id)
	{
		global $conn;
		global $table;
		$query = "DELETE FROM ".$table." WHERE id=".$id;
		if(mysqli_query($conn, $query))
		{
			$response=array(
				'status' => 1,
				'status_message' =>'Produit supprime avec succes.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'status_message' =>'La suppression du produit a echoue. '. mysqli_error($conn)
			);
		}
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	switch($request_method)
	{
		
		case 'GET':
			// Retrive Products
			if(!empty($_GET["id"]))
			{
				$id=intval($_GET["id"]);
				getData($id);
			}
			else
			{
				getAllData();
			}
			break;
		default:
			// Invalid Request Method
			header("HTTP/1.0 405 Method Not Allowed");
			break;
			
		case 'POST':
			// Ajouter un produit
			addData();
			break;
			
		case 'PUT':
			// Modifier un produit
			$id = intval($_GET["id"]);
			updateData($id);
			break;
			
		case 'DELETE':
			// Supprimer un produit
			$id = intval($_GET["id"]);
			deleteData($id);
			break;

	}
?>