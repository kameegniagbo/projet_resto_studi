<?php
	// Connect to database
	include("db_connect.php");
	date_default_timezone_set('UTC');
	$request_method = $_SERVER["REQUEST_METHOD"];
	$table = "appUsersXXXX";

	function getAllData()
	{
		global $conn;
		global $table;
		$query = "SELECT * FROM ".$table." ORDER BY id DESC";
		$response = array();
		$result = mysqli_query($conn, $query);
		while($row = mysqli_fetch_assoc($result))
		{
			$response[] = $row;
		}
		header('Content-Type: application/json');
		echo json_encode($response, JSON_PRETTY_PRINT);
	}
	
	function getData($id=0)
	{
		global $conn;
		global $table;
		$query = "SELECT * FROM ".$table;
		if($id != 0)
		{
			$query .= " WHERE id=".$id." LIMIT 1";
		}
		$response = array();
		$result = mysqli_query($conn, $query);
		while($row = mysqli_fetch_assoc($result))
		{
			$response[] = $row;
		}
		header('Content-Type: application/json');
		echo json_encode($response, JSON_PRETTY_PRINT);
	}
	
	function addData()
	{
		global $conn;
		global $table;
		$pays = $_POST["pays"];
		$nom = $_POST["nom"];
		$username = $_POST["username"];
		$password = $_POST["password"];
		$logDateTime = date('Y-m-d H:i:s');
		$query="INSERT INTO ".$table." (nom, pays, username, password, logDateTime) 
		        VALUES('".$nom."', '".$pays."', '".$username."', '".$password."', '".$logDateTime."')";
		if(mysqli_query($conn, $query))
		{
			$insert_id = mysqli_insert_id($conn);
			$response=array(
				'status' => 1,
				'status_message' =>'Donnees ajoutees avec succes #'.$insert_id
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'status_message' =>'ERREUR!.'. mysqli_error($conn)
			);
		}
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	function updateData($id)
	{
		global $conn;
		global $table;
		$_PUT = array();
		parse_str(file_get_contents('php://input'), $_PUT);
		$name = $_PUT["name"];
		$description = $_PUT["description"];
		$price = $_PUT["price"];
		$category = $_PUT["category"];
		$created = 'NULL';
		$modified = date('Y-m-d H:i:s');
		$query="UPDATE ".$table." SET name='".$name."', description='".$description."', price='".$price."', category_id='".$category."', modified='".$modified."' WHERE id=".$id;
		
		if(mysqli_query($conn, $query))
		{
			$response=array(
				'status' => 1,
				'status_message' =>'Produit mis a jour avec succes.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'status_message' =>'Echec de la mise a jour de produit. '. mysqli_error($conn)
			);
			
		}
		
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	function deleteData($id)
	{
		global $conn;
		global $table;
		$query = "DELETE FROM ".$table." WHERE id=".$id;
		if(mysqli_query($conn, $query))
		{
			$response=array(
				'status' => 1,
				'status_message' =>'Produit supprime avec succes.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'status_message' =>'La suppression du produit a echoue. '. mysqli_error($conn)
			);
		}
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	switch($request_method)
	{
		
		case 'GET':
			// Retrive Products
			if(!empty($_GET["id"]))
			{
				$id=intval($_GET["id"]);
				getData($id);
			}
			else
			{
				getAllData();
			}
			break;
		default:
			// Invalid Request Method
			header("HTTP/1.0 405 Method Not Allowed");
			break;
			
		case 'POST':
			// Ajouter un produit
			addData();
			break;
			
		case 'PUT':
			// Modifier un produit
			$id = intval($_GET["id"]);
			updateData($id);
			break;
			
		case 'DELETE':
			// Supprimer un produit
			$id = intval($_GET["id"]);
			deleteData($id);
			break;

	}
?>