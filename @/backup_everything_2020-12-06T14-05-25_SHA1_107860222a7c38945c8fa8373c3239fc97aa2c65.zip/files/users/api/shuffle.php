<?php
	// Connect to database
	include("db_connect.php");
	date_default_timezone_set('UTC');
	$table = "appMeet";

	if(isset($_GET["devId"]))
	{
		$devId = $_GET["devId"];
		$query = "SELECT sexeR, ageR1, ageR2, rechResult, dateResult FROM ".$table." WHERE devId='".$devId."' ";
		$result = mysqli_query($conn, $query);
		//echo mysqli_num_rows($result);
		//echo $query;
		if (mysqli_num_rows($result) > 0 ) 
		{
            $row = mysqli_fetch_assoc($result);
            $sexeR = $row['sexeR'];
            $ageR1 = $row['ageR1'];
            $ageR2 = $row['ageR2'];
            $rechResult = unserialize($row['rechResult']);
            $dateResult = $row['dateResult'];
            $dateToday = date('Y-m-d');
            //echo $query;
            
            if ($dateResult > $dateToday) 
		    {
		        header('Content-Type: application/json');
		        echo json_encode($rechResult, JSON_PRETTY_PRINT);
		    }
		    else
		    {
		        getRandomData();
		    }
		}
	}

	function getRandomData()
	{
		global $conn;
		global $table;
		global $sexeR;
		global $ageR1;
		global $ageR2;
		global $devId;
		
		$shuffleResult = array();
		
		$query = "SELECT pseudo, cel, age, villResid, region, photo, id FROM ".$table." 
		WHERE region='KARA' AND  sexe='".$sexeR."' AND age BETWEEN '".$ageR1."' AND '".$ageR2."' 
		ORDER BY RAND() LIMIT 1";
		$result = mysqli_query($conn, $query);
		if (mysqli_num_rows($result) > 0) 
		{
		    $rowKARA = mysqli_fetch_assoc($result);
		    array_push($shuffleResult, $rowKARA);
		}
		
		$query = "SELECT pseudo, cel, age, villResid, region, photo, id FROM ".$table." 
		WHERE region='CENTRALE' AND  sexe='".$sexeR."' AND age BETWEEN '".$ageR1."' AND '".$ageR2."' 
		ORDER BY RAND() LIMIT 1";
		$result = mysqli_query($conn, $query);
		if (mysqli_num_rows($result) > 0) 
		{
		    $rowCENTRE = mysqli_fetch_assoc($result);
		    array_push($shuffleResult, $rowCENTRE);
		}

		$query = "SELECT pseudo, cel, age, villResid, region, photo, id FROM ".$table." 
		WHERE region='PLATEAUX' AND  sexe='".$sexeR."' AND age BETWEEN '".$ageR1."' AND '".$ageR2."' 
		ORDER BY RAND() LIMIT 1";
		$result = mysqli_query($conn, $query);
		if (mysqli_num_rows($result) > 0) 
		{
		    $rowPLATEAUX = mysqli_fetch_assoc($result);
		    array_push($shuffleResult, $rowPLATEAUX);
		}

		$query = "SELECT pseudo, cel, age, villResid, region, photo, id FROM ".$table." 
		WHERE region='SAVANE' AND  sexe='".$sexeR."' AND age BETWEEN '".$ageR1."' AND '".$ageR2."' 
		ORDER BY RAND() LIMIT 1";
		$result = mysqli_query($conn, $query);
		if (mysqli_num_rows($result) > 0) 
		{
		    $rowSAVANE = mysqli_fetch_assoc($result);
		    array_push($shuffleResult, $rowSAVANE);
		}

		$query = "SELECT pseudo, cel, age, villResid, region, photo, id FROM ".$table." 
		WHERE region='MARITIME' AND  sexe='".$sexeR."' AND age BETWEEN '".$ageR1."' AND '".$ageR2."' 
		ORDER BY RAND() LIMIT 1";
		$result = mysqli_query($conn, $query);
		if (mysqli_num_rows($result) > 0) 
		{
		    $rowMARITIME = mysqli_fetch_assoc($result);
		    array_push($shuffleResult, $rowMARITIME);
		}
		
		updateData($table, $shuffleResult, $devId);
	}

	function updateData($table, $shuffleResult, $devId)
	{
		$newDateResult = date('Y-m-d');
		$newDateResult = date('Y-m-d',strtotime('+6 month',strtotime($newDateResult)));
		$shuffleResultSerialized = serialize($shuffleResult);
		$query="UPDATE ".$table." SET rechResult='".$shuffleResultSerialized."', dateResult='".$newDateResult."' WHERE devId='".$devId."' ";
		//echo $query;
		global $conn;
		if(mysqli_query($conn, $query))
		{
			$response=$shuffleResult;
		}
		else
		{
			$response=array(
				'status' => 0,
				'status_message' =>'Echec de la mise a jour des donnees. '. mysqli_error($conn)
			);
			
		}
		
		header('Content-Type: application/json');
		echo json_encode($response, JSON_PRETTY_PRINT);
	}

?>