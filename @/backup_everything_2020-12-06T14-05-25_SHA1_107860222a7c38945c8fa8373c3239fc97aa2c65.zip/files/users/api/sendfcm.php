<?php

function sendPush($title,$message,$idArticle)
{
    global $conn;
    $query = "SELECT * FROM appUsers";
    $result = mysqli_query($conn, $query);
    
    $registrationIds = array();
    
    while($row = mysqli_fetch_array($result)) {
        array_push($registrationIds, $row['refPushNotif']);
    }
    
    //print_r($registrationIds);

    // API access key from Google API's Console
    // replace API
    define( 'API_ACCESS_KEY', 'AAAAy78YW5E:APA91bH4rfhdyzcq-9cod0-UUdq27dXZN52jiAxi3VIzIOUdxGj_rqQtw3dyC4LYQ1qimbpYjErQ7tsRaHlgARXpGOl1ahbQxV-IuUq8SleOBmsZsQB9jgpoav2MSEF_S3zhv2EJtlZa'); //server key frido
    
    $notification = [
                'body'   => $message,
                'title'     => $title,                    
                "icon" =>  'notification_icon',
                "content_available" => "1"
    ];
    
    $data = [
         "title"             =>$title,  
         "message"           => $message,
         "vibrate" => 1,
         "sound" => 1,
         "content_available" => "1"
    ];
    
    $fields =  [
            'registration_ids'   => $registrationIds,    
            'notification'      => $notification,        
            'data'               => $data,                         
            "priority"           => "high",
            "content_available"  => true
    ];
      
    // $msg = array
    // (
    // 'message' => $message,
    // 'title' => $title,
    // 'vibrate' => 1,
    // 'sound' => 1
    // // you can also add images, additionalData
    // );

    // $fields = array
    // (
    // 'registration_ids' => $registrationIds,
    // 'data' => $msg
    // );

    $headers = array
    (
    'Authorization: key=' . API_ACCESS_KEY,
    'Content-Type: application/json'
    );

    $ch = curl_init();
    curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
    curl_setopt( $ch,CURLOPT_POST, true );
    curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
    curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
    curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
    $result = curl_exec($ch );
    
    if ($result === FALSE) {
        die('Oops! FCM Send Error: ' . curl_error($ch));
       }
       curl_close($ch);
       return $result;
}

function sendOnePush($title,$message,$userId)
{
    global $conn;
    $query = "SELECT * FROM appUsers WHERE id=".$userId;
    $result = mysqli_query($conn, $query);
    
    $registrationIds = array();
    
    while($row = mysqli_fetch_array($result)) {
        array_push($registrationIds, $row['fcm']);
    }
    
    //print_r($registrationIds);

    // API access key from Google API's Console
    // replace API
    define( 'API_ACCESS_KEY', 'AAAAy78YW5E:APA91bH4rfhdyzcq-9cod0-UUdq27dXZN52jiAxi3VIzIOUdxGj_rqQtw3dyC4LYQ1qimbpYjErQ7tsRaHlgARXpGOl1ahbQxV-IuUq8SleOBmsZsQB9jgpoav2MSEF_S3zhv2EJtlZa'); //server key frido

    $msg = array
    (
    'message' => $message,
    'title' => $title,
    'vibrate' => 1,
    'sound' => 1,
    'click_action' => "FLUTTER_NOTIFICATION_CLICK"

    // you can also add images, additionalData
    );

    $fields = array
    (
    'registration_ids' => $registrationIds,
    'data' => $msg,
    'notification'=> array
                    (
                    'title' => $title,
                    'body' => $message
                    )
    );

    $headers = array
    (
    'Authorization: key=' . API_ACCESS_KEY,
    'Content-Type: application/json'
    );

    $ch = curl_init();
    curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
    curl_setopt( $ch,CURLOPT_POST, true );
    curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
    curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
    curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
    $result = curl_exec($ch );
    
    if ($result === FALSE) {
        die('Oops! FCM Send Error: ' . curl_error($ch));
       }
       curl_close($ch);
       return $result;
}
//sendOnePush("tt","texte","79");
//sendPush($title,$message,$rub,$idArticle);

?>