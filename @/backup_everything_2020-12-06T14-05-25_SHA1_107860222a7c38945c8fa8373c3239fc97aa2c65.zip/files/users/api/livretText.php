<?php
	// Connect to database
	include("db_connect.php");
	require_once("../../mobile/fieldsCheckingFunctions.php");
	date_default_timezone_set('UTC');
	$request_method = $_SERVER["REQUEST_METHOD"];
	$table = "appLivretText";

	function getAllData()
	{
		global $conn;
		global $table;
		$query = "SELECT * FROM ".$table." ORDER BY id_post DESC";
		$response = array();
		$result = mysqli_query($conn, $query);
		while($row = mysqli_fetch_assoc($result))
		{
			$response[] = $row;
		}
		header('Content-Type: application/json');
		echo json_encode($response, JSON_PRETTY_PRINT);
	}
	
	function getData($id=0)
	{
		global $conn;
		global $table;
		$query = "SELECT * FROM ".$table;
		if($id != 0)
		{
			$query .= " WHERE id=".$id." LIMIT 1";
		}
		$response = array();
		$result = mysqli_query($conn, $query);
		while($row = mysqli_fetch_assoc($result))
		{
			$response[] = $row;
		}
		header('Content-Type: application/json');
		echo json_encode($response, JSON_PRETTY_PRINT);
	}
	
	function addData()
	{
	    
		global $conn;
		global $table;
		
		$numLivret = $_POST["numLivret"];
		$date_text = $_POST["date1"]." ".$_POST["date2"]." ".$_POST["date3"]." ".$_POST["date4"];
		$ref_evang = inputSanitize($_POST["ref_evang"]);
		$moisAnnLivret = $_POST["date33"]."-".$_POST["date4"];
		$textSemTempsLiturg = inputSanitize($_POST["textSemTempsLiturg"]);
		$nom_saint = inputSanitize($_POST["nom_saint"]);
		$logDateTime = date('Y-m-d H:i:s');
		$refTextImg = $_POST["date2"].$_POST["date33"].$_POST["date4"];
		$todayDate = $_POST["date2"]."-".$_POST["date33"]."-".$_POST["date4"];
        
        $img_post   = 'imgPost_'. $refTextImg; // 5dab1961e93a7-1571494241
        $img_post   = $img_post . '.jpg'; // 5dab1961e93a7_1571494241.jpg
        $imgPost_path = "../appImages/". $img_post;
        $img_post = "https://paroledevie.online/users/appImages/". $img_post;

        $text_post   = 'textPost_'. $refTextImg; // 5dab1961e93a7-1571494241
        $text_post   = $text_post . '.html'; // 5dab1961e93a7_1571494241.html
        $textPost_path = "../appTextes/". $text_post;
        $text_post = "https://paroledevie.online/users/appTextes/". $text_post;

        move_uploaded_file($_FILES['img_post']['tmp_name'], $imgPost_path);
        move_uploaded_file($_FILES['text_post']['tmp_name'], $textPost_path);

    		$query="INSERT INTO ".$table." (date_text, numLivret, moisAnnLivret, textSemTempsLiturg, todayDate, nom_saint, ref_evang, text_post, img_post, logDateTime) 
    		        VALUES('".$date_text."', '".$numLivret."', '".$moisAnnLivret."', '".$textSemTempsLiturg."', '".$todayDate."', '".$nom_saint."', '".$ref_evang."', '".$text_post."', '".$img_post."', '".$logDateTime."')";
    		if(mysqli_query($conn, $query))
    		{
    			$insert_id = mysqli_insert_id($conn);
    			$response=array(
    				'status' => 1,
    				'status_message' =>'Donnees ajoutees avec succes #'.$insert_id
    			);
    // 			$titlePush="Parole de Vie";
    //             $messagePush="Lectures du jour : ". $ref_evang;
    //             include("sendfcm.php");
    //             sendPush($titlePush,$messagePush,$month);
    		}
    		else
    		{
    			$response=array(
    				'status' => 0,
    				'status_message' =>'ERREUR!.'. mysqli_error($conn)
    			);
    		}
    		header('Content-Type: application/json');
    		echo json_encode($response);

	}
	
	function updateData($id)
	{
		global $conn;
		global $table;
		$_PUT = array();
		parse_str(file_get_contents('php://input'), $_PUT);
		$name = $_PUT["name"];
		$description = $_PUT["description"];
		$price = $_PUT["price"];
		$category = $_PUT["category"];
		$created = 'NULL';
		$modified = date('Y-m-d H:i:s');
		$query="UPDATE ".$table." SET name='".$name."', description='".$description."', price='".$price."', category_id='".$category."', modified='".$modified."' WHERE id=".$id;
		
		if(mysqli_query($conn, $query))
		{
			$response=array(
				'status' => 1,
				'status_message' =>'Produit mis a jour avec succes.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'status_message' =>'Echec de la mise a jour de produit. '. mysqli_error($conn)
			);
			
		}
		
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	function deleteData($id)
	{
		global $conn;
		global $table;
		$query = "DELETE FROM ".$table." WHERE id=".$id;
		if(mysqli_query($conn, $query))
		{
			$response=array(
				'status' => 1,
				'status_message' =>'Produit supprime avec succes.'
			);
		}
		else
		{
			$response=array(
				'status' => 0,
				'status_message' =>'La suppression du produit a echoue. '. mysqli_error($conn)
			);
		}
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	switch($request_method)
	{
		
		case 'GET':
			// Retrive Products
			if(!empty($_GET["id"]))
			{
				$id=intval($_GET["id"]);
				getData($id);
			}
			else
			{
				getAllData();
			}
			break;
		default:
			// Invalid Request Method
			header("HTTP/1.0 405 Method Not Allowed");
			break;
			
		case 'POST':
			// Ajouter un produit
			addData();
			break;
			
		case 'PUT':
			// Modifier un produit
			$id = intval($_GET["id"]);
			updateData($id);
			break;
			
		case 'DELETE':
			// Supprimer un produit
			$id = intval($_GET["id"]);
			deleteData($id);
			break;

	}
?>