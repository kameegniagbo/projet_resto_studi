<?php
	$server = "localhost";
	$username = "paroledevie";
	$password = "pdv@mysql@DB";
	$db = "paroledevie";
	$conn = mysqli_connect($server, $username, $password, $db);
	mysqli_set_charset($conn,"utf8mb4");
?>
