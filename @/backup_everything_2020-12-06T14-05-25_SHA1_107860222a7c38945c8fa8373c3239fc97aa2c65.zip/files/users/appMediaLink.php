<?php
require_once 'init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) {
    die();
}
?>

<div class="row">
	<div class="col-12 col-md-12">
	    <br>
	    <h1 align="">Liste des Liens Medias - Parole de Vie</h1>
	    <br>
<?php
//########################################################################################################
date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$thisMonth = date('m');

        $query = $db->query("SELECT * FROM appMediaLink ORDER BY id ASC")->results();
        $table = "appMediaLink";
        $titre ="Les Liens";
        $opts = [
        'nodupe'=>1, //hides duplicate button
        'nodel'=>1, //hides duplicate button
        'keys'=>array("#","DESCRIPTION.","TAILLE","LIEN"),
        ];
        quickCrudMediaLink($query,$table,$opts);

//########################################################################################################
?>
	</div>
</div>

<script>
$(document).ready(function () {
    $(".insert").click(function() {
        var dataToSend = new FormData();
        dataToSend.append('pays',  $('#pays').find(":selected").text());
        dataToSend.append('nom', $("#nom").val());
        dataToSend.append('username', $("#username").val());
        dataToSend.append('password', $("#password").val());
        $.ajax({
          type: 'POST',
          url: "<?=$us_url_root?>users/api/premium",
          data: dataToSend,
          //cache: false,
          datatype: 'json',
          enctype: 'multipart/form-data',
          processData: false,
          contentType: false,
          timeout: 10000,
    
            success: function (data) {
              //console.log(data.status);
              $("#result").html(data.status_message);
              $("#result").show();
              setTimeout(function(){ location.reload(true); }, 2000);
            },
            error: function (request,error) {
                // This callback function will trigger on unsuccessful action
                alert('Problème de connexion, veuillez ressayer!');
                //alert(error);
            }
          });
    });
});
</script>

<?php require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; ?>