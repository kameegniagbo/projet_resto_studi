<?php
require_once 'init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) {
    die();
}
?>

<div class="row">
	<div class="col-12 col-md-12">
	    <br>
	    <h1 align="">Liste des Livrets - Parole de Vie</h1>
	    <br>
<?php
//########################################################################################################
date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$thisMonth = date('m');

        $query = $db->query("SELECT id, numLivret, moisAnnLivret, textMoisAnnLivret, textLivret, imgLivret, logDateTime FROM appLivret ORDER BY id DESC")->results();
        $table = "appLivret";
        $titre ="Les Livrets";
        $opts = [
        'nodupe'=>1, //hides duplicate button
        'nodel'=>1, //hides duplicate button
        'keys'=>array("#","N° Livret","MM-AAAA","Mois année","Textes Livret","Affiche","Date"),
        ];
        quickCrudLivret($query,$table,$opts);

//########################################################################################################
?>
	</div>
</div>

<!-- Modal debut  -->
<div class="modal fade" id="modalNewData" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle">Nouveau Livret - Parole de Vie</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  
          <div class="row">
            
                <div class="col-md-6">
                    <form class="editableForm" id="form1" >
                        <div class="form-group row" style="margin-left: 0px;">
                          <div class="col-xs-4">
                            <label for="ex3">Mois</label>
                              <select class="form-control" id="mois" name="mois">
                                <option value="01">Janvier</option>
                                <option value="02">Fevier</option>
                                <option value="03">Mars</option>
                                <option value="04">Avril</option>
                                <option value="05">Mai</option>
                                <option value="06">Juin</option>
                                <option value="07">Juillet</option>
                                <option value="08">Aout</option>
                                <option value="09">Septembre</option>
                                <option value="10">Octobre</option>
                                <option value="11">Novembre</option>
                                <option value="12">Decembre</option>
                              </select>                          
                          </div>
                          <div class="col-xs-4">
                            <label for="ex3">Année</label>
                              <select class="form-control" id="annee" name="annee">
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                              </select>                          
                          </div>
                      </div>
                      <div class="form-group">
                        <label for="">Numero Livret</label><br>
                        <input class="form-control" type="text" name="numLivret" id="numLivret" >
                      </div>
                      <div class="form-group">
                        <label for="">Liste titres Extra</label><br>
                        <textarea class="form-control" type="text" name="listPartExtra" id="listPartExtra" rows="3"></textarea>
                      </div>
        
                      <div class="alert alert-success text-center" id="result" style="display:none;"></div>
                </div>
                <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Textes Livret</label><br>
                        <input class="form-control" type="file" name="textLivret" id="textLivret" >
                      </div>
                      <div class="form-group">
                        <label for="">Affiche Livret</label><br>
                        <input class="form-control" type="file" name="imgLivret" id="imgLivret" >
                      </div>
                      </form>
                </div>
                
            
          </div>
  
     </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
        <button type="button" name="button" data-form="formsante" class="btn btn-primary insert">Valider</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal fin  -->
  
<script>
$(document).ready(function () {
    $(".insert").click(function() {
        var dataToSend = new FormData();
        dataToSend.append('imgLivret', $('#imgLivret')[0].files[0]);
        dataToSend.append('textLivret', $('#textLivret')[0].files[0]);
        dataToSend.append('numLivret', $("#numLivret").val());
        dataToSend.append('listPartExtra', $("#listPartExtra").val());
        dataToSend.append('mois', $("#mois").val());
        dataToSend.append('annee', $("#annee").val());
        dataToSend.append('moisText',  $('#mois').find(":selected").text());
        dataToSend.append('anneeText',  $('#annee').find(":selected").text());
        $.ajax({
          type: 'POST',
          url: "<?=$us_url_root?>users/api/livret.php",
          data: dataToSend,
          //cache: false,
          datatype: 'json',
          enctype: 'multipart/form-data',
          processData: false,
          contentType: false,
          timeout: 10000,
    
            success: function (data) {
              //console.log(data.status);
              $("#result").html(data.status_message);
              $("#result").show();
              setTimeout(function(){ location.reload(true); }, 2000);
            },
            error: function (request,error) {
                // This callback function will trigger on unsuccessful action
                alert('Problème de connexion, veuillez ressayer!');
                //alert(error);
            }
          });
    });
});
</script>

<?php require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; ?>