<?php
require_once 'init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) {
    die();
}
?>

<div class="row">
	<div class="col-12 col-md-12" style="display: inline-block">
	    <br>
	    <h1 align="">Rapports - Parole de Vie</h1>
	    <br>

            <form class="form-inline" id="form1" >
                
                <div class="form-group row" style="margin: 10px;">

                  <div class="col-xs-3">
                      <select class="form-control" id="dateDebut1" name="dateDebut1">
                        <option>01</option>
                        <option>02</option>
                        <option>03</option>
                        <option>04</option>
                        <option>05</option>
                        <option>06</option>
                        <option>07</option>
                        <option>08</option>
                        <option>09</option>
                        <option>10</option>
                        <option>11</option>
                        <option>12</option>
                        <option>13</option>
                        <option>14</option>
                        <option>15</option>
                        <option>16</option>
                        <option>17</option>
                        <option>18</option>
                        <option>19</option>
                        <option>20</option>
                        <option>21</option>
                        <option>22</option>
                        <option>23</option>
                        <option>24</option>
                        <option>25</option>
                        <option>26</option>
                        <option>27</option>
                        <option>28</option>
                        <option>29</option>
                        <option>30</option>
                        <option>31</option>
                      </select>                          
                  </div>
                  <div class="col-xs-4">
                      <select class="form-control" id="dateDebut2" name="dateDebut2">
                        <option value="01">Janvier</option>
                        <option value="02">Fevier</option>
                        <option value="03">Mars</option>
                        <option value="04">Avril</option>
                        <option value="05">Mai</option>
                        <option value="06">Juin</option>
                        <option value="07">Juillet</option>
                        <option value="08">Aout</option>
                        <option value="09">Septembre</option>
                        <option value="10">Octobre</option>
                        <option value="11">Novembre</option>
                        <option value="12">Decembre</option>
                      </select>                          
                  </div>
                  <div class="col-xs-4">
                      <select class="form-control" id="dateDebut3" name="dateDebut3">
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                      </select>                          
                  </div>
                  
                </div>
                
                <div class="form-group row" style="margin: 10px;">

                  <div class="col-xs-3">
                      <select class="form-control" id="dateFin1" name="dateFin1">
                        <option>01</option>
                        <option>02</option>
                        <option>03</option>
                        <option>04</option>
                        <option>05</option>
                        <option>06</option>
                        <option>07</option>
                        <option>08</option>
                        <option>09</option>
                        <option>10</option>
                        <option>11</option>
                        <option>12</option>
                        <option>13</option>
                        <option>14</option>
                        <option>15</option>
                        <option>16</option>
                        <option>17</option>
                        <option>18</option>
                        <option>19</option>
                        <option>20</option>
                        <option>21</option>
                        <option>22</option>
                        <option>23</option>
                        <option>24</option>
                        <option>25</option>
                        <option>26</option>
                        <option>27</option>
                        <option>28</option>
                        <option>29</option>
                        <option>30</option>
                        <option>31</option>
                      </select>                          
                  </div>
                  <div class="col-xs-4">
                      <select class="form-control" id="dateFin2" name="dateFin2">
                        <option value="01">Janvier</option>
                        <option value="02">Fevier</option>
                        <option value="03">Mars</option>
                        <option value="04">Avril</option>
                        <option value="05">Mai</option>
                        <option value="06">Juin</option>
                        <option value="07">Juillet</option>
                        <option value="08">Aout</option>
                        <option value="09">Septembre</option>
                        <option value="10">Octobre</option>
                        <option value="11">Novembre</option>
                        <option value="12">Decembre</option>
                      </select>                          
                  </div>
                  <div class="col-xs-4">
                      <select class="form-control" id="dateFin3" name="dateFin3">
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                      </select>                          
                  </div>
                  
                </div>
                <button type="button" name="button" class="btn btn-primary btnValid">Valider</button>
            </form>
            

<?php
//##################################################################################

date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$thisMonth = date('m');

//##################################################################################
?>


	</div>
</div>

  
<script>
$(document).ready(function () {
    $(".btnValid").click(function(event){
        event.preventDefault();
        var dataToSend = new FormData();
        dataToSend.append('dateDebut1',  $('#dateDebut1').find(":selected").val());
        dataToSend.append('dateDebut2',  $('#dateDebut2').find(":selected").val());
        dataToSend.append('dateDebut3',  $('#dateDebut3').find(":selected").val());
        dataToSend.append('dateFin1',  $('#dateFin1').find(":selected").val());
        dataToSend.append('dateFin2',  $('#dateFin2').find(":selected").val());
        dataToSend.append('dateFin3',  $('#dateFin3').find(":selected").val());
        $.ajax({
          type: 'POST',
          url: "<?=$us_url_root?>users/api/rapport",
          data: dataToSend,
          //cache: false,
          datatype: 'json',
          enctype: 'multipart/form-data',
          processData: false,
          contentType: false,
          timeout: 10000,
    
            success: function (data) {
              //console.log(data.status);
              $("#result").html(data);
              //$("#result").show();
              //setTimeout(function(){ location.reload(true); }, 2000);
            },
            error: function (request,error) {
                // This callback function will trigger on unsuccessful action
                alert('Problème de connexion, veuillez ressayer!');
                //alert(error);
            }
          });
    });
});
</script>

<?php require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; ?>