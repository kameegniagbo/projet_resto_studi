<?php
require_once 'init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) {
    die();
}
?>

<div class="row">
	<div class="col-12 col-md-12">
	    <br>
	    <h1 >Demandes / Suggestions / Messages - Parole de Vie</h1>
	    <br>

  <!-- Nav tabs -->
  <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" data-toggle="tab" href="#chphone">CHANGEMENT TELEPHONE</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#modifprofil">MODIFICATION PROFIL</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#msgclt">MESSAGE UTILISATEUR</a>
    </li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div id="chphone" class="container-fluid tab-pane active"><br>
      <h3>CHANGEMENT TELEPHONE</h3>

<?php
//########################################################################################################
date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$thisMonth = date('m');

        $query = $db->query("SELECT id, nom, phoneID, username, password, statut, logDateTime FROM appChangePhone ORDER BY id DESC")->results();
        $table = "appChangePhone";
        $titre ="Les Paiements";
        $opts = [
        'nodupe'=>1, //hides duplicate button
        'nodel'=>1, //hides duplicate button
        'keys'=>array("#","NOM","NV. PHONE UUID","NUM. TEL.","PASSWORD", "STATUT", "DATE"),
        ];
        quickCrudChangePhone($query,$table,$opts);

//########################################################################################################
?>
    </div>
    <div id="modifprofil" class="container-fluid tab-pane fade"><br>
      <h3>MODIFICATION PROFIL</h3>
<?php
//########################################################################################################
date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$thisMonth = date('m');

        $query = $db->query("SELECT id, username, motif, newVal, statut, logDateTime FROM appChangeProfil ORDER BY id DESC")->results();
        $table = "appChangeProfil";
        $titre ="Les Paiements";
        $opts = [
        'nodupe'=>1, //hides duplicate button
        'nodel'=>1, //hides duplicate button
        'keys'=>array("#","NUM. TEL.","MOTIF","NV. VALEURS", "STATUT", "DATE"),
        ];
        quickCrudChangeProfilData($query,$table,$opts);

//########################################################################################################
?>
    </div>
    <div id="msgclt" class="container-fluid tab-pane fade"><br>
      <h3>MESSAGE UTILISATEUR</h3>
      <p>Coming soon.</p>
    </div>
  </div>


	</div>
</div>


<?php require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; ?>