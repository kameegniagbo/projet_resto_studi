<?php
require_once 'init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) {
    die();
}
?>

<div class="row">
	<div class="col-12 col-md-12">
	    <br>
	    <h1 align="">Liste des Lectures - Parole de Vie</h1>
	    <br>
<?php
//########################################################################################################
date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$thisMonth = date('m');

        $query = $db->query("SELECT id_post, date_text, numLivret, moisAnnLivret, textSemTempsLiturg, nom_saint, ref_evang, text_post, img_post FROM appLivretText ORDER BY id_post DESC")->results();
        $table = "appLivretText";
        $titre ="Les lectures quotidiennes";
        $opts = [
        'nodupe'=>1, //hides duplicate button
        'nodel'=>1, //hides duplicate button
        'keys'=>array("#","Date","N° Livret","MM-AAAA","Temps Liturgique","St. Nom","Ref. Lecture","Lecture","Image"),
        ];
        quickCrudTextLivret($query,$table,$opts);

//########################################################################################################
?>
	</div>
</div>

<!-- Modal debut  -->
<div class="modal fade" id="modalNewData" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle">Nouvelle Lecture - Parole de Vie</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  
          <div class="row">
            
                <div class="col-md-6">
                    <form class="editableForm" id="form1" >
                        <div class="form-group row" style="margin-left: 0px;">
                          <div class="col-xs-2">
                            <label for="ex1">Jour</label>
                              <select class="form-control" id="date1" name="date1">
                                <option>Lundi</option>
                                <option>Mardi</option>
                                <option>Mercredi</option>
                                <option>Jeudi</option>
                                <option>Vendredi</option>
                                <option>Samedi</option>
                                <option>Dimanche</option>
                              </select>
                          </div>
                          <div class="col-xs-3">
                            <label for="ex2">Date</label>
                              <select class="form-control" id="date2" name="date2">
                                <option>01</option>
                                <option>02</option>
                                <option>03</option>
                                <option>04</option>
                                <option>05</option>
                                <option>06</option>
                                <option>07</option>
                                <option>08</option>
                                <option>09</option>
                                <option>10</option>
                                <option>11</option>
                                <option>12</option>
                                <option>13</option>
                                <option>14</option>
                                <option>15</option>
                                <option>16</option>
                                <option>17</option>
                                <option>18</option>
                                <option>19</option>
                                <option>20</option>
                                <option>21</option>
                                <option>22</option>
                                <option>23</option>
                                <option>24</option>
                                <option>25</option>
                                <option>26</option>
                                <option>27</option>
                                <option>28</option>
                                <option>29</option>
                                <option>30</option>
                                <option>31</option>
                              </select>                          
                          </div>
                          <div class="col-xs-4">
                            <label for="ex3">Mois</label>
                              <select class="form-control" id="date3" name="date3">
                                <option value="01">Janvier</option>
                                <option value="02">Fevier</option>
                                <option value="03">Mars</option>
                                <option value="04">Avril</option>
                                <option value="05">Mai</option>
                                <option value="06">Juin</option>
                                <option value="07">Juillet</option>
                                <option value="08">Aout</option>
                                <option value="09">Septembre</option>
                                <option value="10">Octobre</option>
                                <option value="11">Novembre</option>
                                <option value="12">Decembre</option>
                              </select>                          
                          </div>
                          <div class="col-xs-4">
                            <label for="ex3">Année</label>
                              <select class="form-control" id="date4" name="date4">
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                              </select>                          
                          </div>
                      </div>
                      <div class="form-group">
                        <label for="">St. Nom(s)</label><br>
                        <input class="form-control" type="text" name="nom_saint" id="nom_saint" >
                      </div>
                      <div class="form-group">
                        <label for="">Ref. Evangile</label><br>
                        <input class="form-control" type="text" name="ref_evang" id="ref_evang" >
                      </div>
        
                      <div class="alert alert-success text-center" id="result" style="display:none;"></div>
                </div>
                <div class="col-md-6">
                      <div class="form-group">
                        <label for="">Numero Livret</label><br>
                        <input class="form-control" type="text" name="numLivret" id="numLivret" >
                      </div>
                      <div class="form-group">
                        <label for="">Semaine et Temps liturgique</label><br>
                        <input class="form-control" type="text" name="textSemTempsLiturg" id="textSemTempsLiturg" >
                      </div>
                      <div class="form-group">
                        <label for="">Fichier HTML</label><br>
                        <input class="form-control" type="file" name="text_post" id="text_post" >
                      </div>
                      <div class="form-group">
                        <label for="">Image</label><br>
                        <input class="form-control" type="file" name="img_post" id="img_post" >
                      </div>
                      </form>
                </div>
            
          </div>
  
     </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
        <button type="button" name="button" data-form="formsante" class="btn btn-primary insert">Valider</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal fin  -->
  
<script>
$(document).ready(function () {
    $(".insert").click(function() {
        var dataToSend = new FormData();
        dataToSend.append('img_post', $('#img_post')[0].files[0]);
        dataToSend.append('text_post', $('#text_post')[0].files[0]);
        dataToSend.append('numLivret', $("#numLivret").val());
        dataToSend.append('textSemTempsLiturg', $("#textSemTempsLiturg").val());
        dataToSend.append('nom_saint', $("#nom_saint").val());
        dataToSend.append('ref_evang', $("#ref_evang").val());
        dataToSend.append('date1',  $('#date1').find(":selected").text());
        dataToSend.append('date2',  $('#date2').find(":selected").text());
        dataToSend.append('date3',  $('#date3').find(":selected").text());
        dataToSend.append('date33',  $('#date3').find(":selected").val());
        dataToSend.append('date4',  $('#date4').find(":selected").text());
        $.ajax({
          type: 'POST',
          url: "<?=$us_url_root?>users/api/livretText.php",
          data: dataToSend,
          //cache: false,
          datatype: 'json',
          enctype: 'multipart/form-data',
          processData: false,
          contentType: false,
          timeout: 10000,
    
            success: function (data) {
              //console.log(data.status);
              $("#result").html(data.status_message);
              $("#result").show();
              setTimeout(function(){ location.reload(true); }, 2000);
            },
            error: function (request,error) {
                // This callback function will trigger on unsuccessful action
                alert('Problème de connexion, veuillez ressayer!');
                //alert(error);
            }
          });
    });
});
</script>

<?php require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; ?>