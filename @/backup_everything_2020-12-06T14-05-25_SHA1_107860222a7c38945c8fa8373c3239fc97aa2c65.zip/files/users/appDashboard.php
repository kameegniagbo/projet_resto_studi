<?php
require_once 'init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) {
    die();
}

include("chartjs/dashboard.php");

?>

<div class="row">

	<div class="col-12 col-md-12">
	    <br>
	    <h1 align="">Tableau de bord</h1>
	    <br>
<!--========================================================================-->

          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-3 col-md-3 mb-12">
              <div class="card border-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">UTILISATEURS INSCRITS</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "59990";  ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-user fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-3 mb-12">
              <div class="card border-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">UTILISATEURS ABONNÉS</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "60000";  ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-calendar fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-3 mb-12">
              <div class="card bg-danger border-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">NBRE ABONMT.</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "30000";  ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-book fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-3 mb-12">
              <div class="card border-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">SOMME ABONMT.</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "50000000";  ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-dollar fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
        </div>
        <br>

          <!-- Content Row -->

<!-- ================================================================ -->

          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-3 col-md-3 mb-12">
              <div class="card border-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">ABONNÉS EXPIRANTS</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "80000";  ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-user fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-3 mb-12">
              <div class="card border-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">XXX</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "75000";  ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-calendar fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-3 mb-12">
              <div class="card bg-danger border-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">XXX</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "100000";  ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-book fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-3 mb-12">
              <div class="card border-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">XXX</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "90000";  ?></div>
                    </div>
                    <div class="col-auto">
                      <i class="fa fa-dollar fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
        </div>
        <br>

          <!-- Content Row -->

<!-- ================================================================ -->
        
        <!-- Graphes -->
        
        <div class="row">
           <div class="col-md-7">
             <div class="card card-default shadow" style="text-align: -webkit-center;"> <?php echo $Bar;  ?> </div>
            </div>
            <div class="col-md-5">
             <div class="card card-default shadow" style="text-align: -webkit-center;"> <?php echo $Pie; ?> </div>
            </div>
        </div>

<!-- ================================================================ -->

	
</div>
<script src="chartjs/js/Chart.min.js"></script>
<script src="chartjs/js/driver.js"></script>
<script>
    (function () {
        loadChartJsPhp();
    })();
</script>
<?php require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; ?>