<?php
require_once 'init.php';
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) {
    die();
}
?>

<div class="row">
	<div class="col-12 col-md-12">
	    <br>
	    <h1 align="">Liste des Utilisateurs - Parole de Vie</h1>
	    <br>
<?php
//########################################################################################################
date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');
$thisMonth = date('m');

        $query = $db->query("SELECT id, nom, email, pays, username, password, phoneID, logDateTime FROM appUsers ORDER BY id DESC")->results();
        $table = "appUsers";
        $titre ="Les Utilisateurs";
        $opts = [
        'nodupe'=>1, //hides duplicate button
        'nodel'=>1, //hides duplicate button
        'keys'=>array("#","Nom","E-mail","Pays","Numero Tel.","Pass.","UUID.","Date"),
        ];
        quickCrudUsers($query,$table,$opts);

//########################################################################################################
?>
	</div>
</div>

<!-- Modal debut  -->
<div class="modal fade" id="modalNewData" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle">Nouvel utilisateur - Parole de Vie</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  
          <div class="row">
            
                <div class="col-md-12">
                    <form class="editableForm" id="form1" >
                        <div class="form-group">
                              <select class="form-control" id="pays" name="pays">
                                <option value="tg">TOGO</option>
                                <option value="ci">COTE D'IVOIRE</option>
                                <option value="ng">NIGER</option>
                                <option value="bn">BENIN</option>
                                <option value="bf">BURKINA</option>
                              </select>
                      </div>
                      <div class="form-group">
                        <label for="">Nom(s)</label><br>
                        <input class="form-control" type="text" name="nom" id="nom" >
                      </div>
                      <div class="form-group">
                        <label for="">Numero de telephone</label><br>
                        <input class="form-control" type="text" name="username" id="username"  maxlength="12" placeholder="">
                      </div>
                      <div class="form-group">
                        <label for="">Mot de passe</label><br>
                        <input class="form-control" type="password" name="password" id="password" maxlength="12" placeholder="12 caracteres maximum">
                      </div>
        
                      <div class="alert alert-success text-center" id="result" style="display:none;"></div>
                </div>
          </div>
  
     </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
        <button type="button" name="button" data-form="formsante" class="btn btn-primary insert">Valider</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal fin  -->
  
<script>
$(document).ready(function () {
    $(".insert").click(function() {
        var dataToSend = new FormData();
        dataToSend.append('pays',  $('#pays').find(":selected").text());
        dataToSend.append('nom', $("#nom").val());
        dataToSend.append('username', $("#username").val());
        dataToSend.append('password', $("#password").val());
        $.ajax({
          type: 'POST',
          url: "<?=$us_url_root?>users/api/users",
          data: dataToSend,
          //cache: false,
          datatype: 'json',
          enctype: 'multipart/form-data',
          processData: false,
          contentType: false,
          timeout: 10000,
    
            success: function (data) {
              //console.log(data.status);
              $("#result").html(data.status_message);
              $("#result").show();
              setTimeout(function(){ location.reload(true); }, 2000);
            },
            error: function (request,error) {
                // This callback function will trigger on unsuccessful action
                alert('Problème de connexion, veuillez ressayer!');
                //alert(error);
            }
          });
    });
});
</script>

<?php require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; ?>