<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Parole de Vie</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  .jumbotron {
    background-image: url('img1.jpg');
		background-repeat: no-repeat;
		background-position: top center;
    background-color: #fff;
    height: 600px;
  }
  .container {
    padding-top: 30px;
  }

/*=================================================================*/

@media only screen and (min-device-width: 320px) {
	.jumbotron {
		background-repeat: no-repeat;
    background-position: center top;
		background-size: 100% auto;
    }
}

@media only screen and (min-device-width: 480px) {
	.jumbotron {
		background-repeat: no-repeat;
    background-position: center top;
		background-size: 100% auto;
    }
}

@media only screen and (min-device-width: 768px) {
	.jumbotron {
		background-repeat: no-repeat;
    background-position: center top;
		background-size: 100% auto;
    }
}

@media only screen and (min-device-width: 992px) {
	.jumbotron {
		background-repeat: no-repeat;
    background-position: center top;
		background-size: 100% auto;
    }
}

@media only screen and (min-device-width: 1200px) {
	.jumbotron {
		background-repeat: no-repeat;
		background-position: center top;
		background-size: 70% auto;
		/* height: 800px; */
    }
}

@media only screen and (min-device-width: 1600px) {
	.jumbotron {
		background-repeat: no-repeat;
		background-position: center top;
		background-size: 100% auto;
		/* height: 1067px; */
    }
}


  </style>
</head>
<body >

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="legacy.html">CONDITIONS GENERALES D'UTILISTATION</a></li>
        <li><a href="https://play.google.com/store/apps/details?id=com.paroledevie.fri">TELECHARGER</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

< div class="row">
<div class="container">
<div class="col-md-12 jumbotron"></div>
</div>
</div>

<!--  -->

</body>
</html>