;<?php die();?>
apibuilder = 0
charts = 1
quickcrud = 1