<?php
//This script is called whenever you delete a user.  It's a good way to clean up data that you're
//storing on each user and may be needed for GDPR compliance.
//you will have access to the $id variable which is the user id that you are deleting.
//dnd($id);
