<?php
//There are a lot of things that happen just after login.
//To document them here:
//1. This file. Put whatever you want, except redirects
//2. $dest - if a user hit a login required page when not logged in, they will go here after login
//3. usersc/scripts/custom_login_script. Put whatever you want in there.
//4 homepage.  Whatever is specified in the settings panel and serves as a default


?>
