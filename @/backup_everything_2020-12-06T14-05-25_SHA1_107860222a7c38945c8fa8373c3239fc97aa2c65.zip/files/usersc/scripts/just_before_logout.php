<?php
//Whatever happens in this script happens just before the user is officially logged out. This is a great time to update the database etc while you still have access to the $user variable). 
?>