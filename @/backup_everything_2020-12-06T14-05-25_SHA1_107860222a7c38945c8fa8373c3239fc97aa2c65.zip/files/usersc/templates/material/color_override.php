<link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">
<style media="screen">

/* override footer bg color */
footer {
  background-color: #212121 !important;
  /* if you don't like the sticky footer, comment in the line below */
  /* position: relative !important; */
}

/* override footer text color */
footer.page-footer .footer-copyright {
  color: white !important;

}


.navbar {
  background-color: #212121  !important;

}
</style>
