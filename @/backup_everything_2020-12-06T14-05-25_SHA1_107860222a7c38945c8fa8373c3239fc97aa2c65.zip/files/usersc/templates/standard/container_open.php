<div>
  <!-- feel free to change between container or container fluid -->
  <div class="container-fluid">
