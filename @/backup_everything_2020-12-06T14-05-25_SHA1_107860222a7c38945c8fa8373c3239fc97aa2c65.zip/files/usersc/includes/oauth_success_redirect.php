<?php
/*Whatever you want to do prior to the account.php redirect on oauth_success, you can do here!*/
?>
