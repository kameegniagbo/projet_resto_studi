<?php
/*Include your custom dropdown hooks here! Examples:
  $dropdownString = str_replace('{{lname}}',$user->data()->lname,$dropdownString); */
  $dropdownString = str_replace('{{home}}',lang("MENU_HOME"),$dropdownString);
 ?>
