<?php
ob_start();

date_default_timezone_set('UTC');
$dateTimeNow = date('Y-m-d H:i:s');

//####################################################################

//verifier si la requete est un POST
//check if request method is POST
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
throw new Exception('Ceci nest pas une requete POST');
}

//verifier si la requete POST est au format JSON
//check if POST and JSON in header
$pgg_dataType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';

if(strcasecmp($pgg_dataType, 'application/json') != 0){
throw new Exception('Les donnees ne sont pas au format JSON');
}

//Recevoir les donnees si les verifications sont faites
//get data
$pgg_data = file_get_contents("php://input");

//Decoder les donnees recues
//decode data
$pgg_data_decoded = json_decode($pgg_data, true);

//Verifier si les donnees decodees sont au format JSON
//check if JSON
if(!is_array($pgg_data_decoded)){
throw new Exception('Les donnees recues ne sont pas du type JSON');
}

//####################################################################

//Recuperation des donnees dans des variables
//save data to variables

$pgg_amount = (int)$pgg_data_decoded["amount"];
//$pgg_amount = 3500; ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

if (in_array($pgg_amount, array(700,2000,3500,7000), true ) )
{
  $pgg_tx_reference = $pgg_data_decoded["tx_reference"];
  $pgg_payment_reference = $pgg_data_decoded["payment_reference"];
  $pgg_datetime = $pgg_data_decoded["datetime"];
  $pgg_identifier = $pgg_data_decoded["identifier"];
  $pgg_phone_number = $pgg_data_decoded["phone_number"];
  $pgg_payment_method = $pgg_data_decoded["payment_method"];
}
else {exit;}

//####################################################################

//now save data to database or to a file and set order state to 'complete'

// $file = "cb_data-".$pgg_phone_number."-".uniqid().".txt";
// $data = "Numero de telephone : ".$pgg_phone_number."
// Numero de Transaction PayGateGlobal: ".$pgg_tx_reference."
// Code de Transaction FLOOZ: ".$pgg_payment_reference."
// Montant de la transaction: ".$pgg_amount."
// Date de la transaction: ".$pgg_datetime."
// Methode de paiement: ".$pgg_payment_method."
// Numéro de la commande: ".$pgg_identifier;

// file_put_contents($file, $data);

//#######################################################################

require_once("mobile/crudFunctions.php");
require_once("mobile/fieldsCheckingFunctions.php");

function findUserFullName($usernamex)
{
    $table_name = "appUsers";
    $select="*";
    $where="WHERE username='".$usernamex."' ";
    $result = DBSelect($table_name, $select, $where);
    $row = mysqli_fetch_assoc($result);
    
    return $row["nom"];
}
    
//#####################################################################

$pgg_identifierX = explode("_",$pgg_identifier);
$month = $pgg_identifierX[1];
$appUsername = $pgg_identifierX[2];
$userFullName = findUserFullName($appUsername);

$table_name = "appLivretPay";

$form_data = array(
    'username' => inputSanitize($appUsername),
    'nom' => inputSanitize($userFullName),
    'moisAnnLivret' => inputSanitize($month),
    'tx_reference' => inputSanitize($pgg_tx_reference),
    'payment_reference' => inputSanitize($pgg_payment_reference),
    'amount' => inputSanitize($pgg_amount),
    'datetime' => inputSanitize($pgg_datetime),
    'identifier' => inputSanitize($pgg_identifier),
    'phone_number' => inputSanitize($pgg_phone_number),
    'payment_method' => inputSanitize($pgg_payment_method),
    'logDateTime' => $dateTimeNow
);

list($result, $insertedID) = DBInsert($table_name, $form_data);

if ($result)
{
   echo '1 insert to PAY'."\n"; 
}
else 
{
   echo '0'; 
}

//##############################################################################

function findLivretNum($mAnn)
{
    $table_name = "appLivret";
    $select="*";
    $where="WHERE moisAnnLivret='".$mAnn."' ";
    $result = DBSelect($table_name, $select, $where);
    $row = mysqli_fetch_assoc($result);
    $numLivret = $row["numLivret"];
    
    return $numLivret;
}

//##############################################################################

function suscribeOneYear($numLivretX)
{
  $listNumLivret = "";

    for ($x = 11; $x >= 0; $x--) {
      $listNumLivret .= $x+$numLivretX.",";
    }
    
    return rtrim($listNumLivret, ',');
}

//##############################################################################

function suscribeSixMonth($numLivretX)
{
  $listNumLivret = "";

  for ($x = 5; $x >= 0; $x--) {
      $listNumLivret .= $x+$numLivretX.",";
  }
    
  return rtrim($listNumLivret, ',');
}

//##############################################################################

function suscribeThreeMonth($numLivretX)
{
    $listNumLivret = "";
    for ($x = 2; $x >= 0; $x--) {
      $listNumLivret .= $x+$numLivretX.",";
    }
    
    return rtrim($listNumLivret, ',');
}

//##############################################################################

function saveLivretNumToACL($ux, $mx, $amountx)
{
    global $dateTimeNow;
    global $userFullName;
    
    $table_name = "appLivretACL";
    $select="*";
    $where="WHERE username='".$ux."' ";
    $resultCheck = DBSelect($table_name, $select, $where);
    
    $numLivretACL = findLivretNum($mx); // suscribe only one month
    
    switch ($amountx) {
      case "2000":
        $numLivretACL = suscribeThreeMonth($numLivretACL);
        break;
      case "3500":
        $numLivretACL = suscribeSixMonth($numLivretACL);
        break;
      case "7000":
        $numLivretACL = suscribeOneYear($numLivretACL);
        break;
      // case "150":
      //   $numLivretACL = suscribeSixMonth($numLivretACL);
      //   break;
    }

    if (mysqli_num_rows($resultCheck) < 1)
    {
            $form_data = array(
            'username' => inputSanitize($ux),
            'nom' => inputSanitize($userFullName),
            'typACL' => "Normal",
            'numLivret' => inputSanitize($numLivretACL),
            'logDateTime' => $dateTimeNow
           );
           
           list($resultInsert, $insertedID) = DBInsert($table_name, $form_data);
           
            if ($resultInsert)
            {
               echo '1 insert new to ACL'."\n"; 
            }
            else 
            {
               echo '0'; 
            }
    }
    else
    {
            $form_data = array(
            'numLivret' => $numLivretACL.","
            );
           
            $resultUpdate = DBUpdateConcat($table_name, $form_data, $where);
           
            if ($resultUpdate)
            {
               echo '1 update to ACL'."\n"; 
            }
            else 
            {
               echo '0'; 
            }
    }
}

saveLivretNumToACL($appUsername, $month, $pgg_amount);

ob_end_flush();
?>